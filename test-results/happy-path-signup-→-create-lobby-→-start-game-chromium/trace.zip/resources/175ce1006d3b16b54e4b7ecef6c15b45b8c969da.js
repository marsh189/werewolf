(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d9f6c0fe._.js",
  "static/chunks/_c97b081a._.js"
],
    source: "dynamic"
});
