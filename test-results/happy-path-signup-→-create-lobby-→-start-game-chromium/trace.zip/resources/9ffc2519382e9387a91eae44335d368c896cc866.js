(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/lobby/LobbyHeaderStatus.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LobbyHeaderStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function LobbyHeaderStatus({ lobbyName, started, startingRemainingSeconds }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-start gap-2 mb-3 sm:flex-row sm:items-center sm:gap-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "game-title text-left leading-tight",
                children: lobbyName
            }, void 0, false, {
                fileName: "[project]/components/lobby/LobbyHeaderStatus.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: [
                    'px-3 py-1 rounded-full text-xs font-semibold border',
                    started ? 'bg-red-500/10 text-red-200 border-red-500/30' : 'bg-sky-500/10 text-sky-200 border-sky-500/30'
                ].join(' '),
                children: started ? 'In Progress' : startingRemainingSeconds !== null ? `Starting... ${startingRemainingSeconds}` : 'Waiting'
            }, void 0, false, {
                fileName: "[project]/components/lobby/LobbyHeaderStatus.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/lobby/LobbyHeaderStatus.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = LobbyHeaderStatus;
var _c;
__turbopack_context__.k.register(_c, "LobbyHeaderStatus");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/lobby/LobbyMembersList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LobbyMembersList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function LobbyMembersList({ members, hostUserId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "game-section-title",
                    children: "Players"
                }, void 0, false, {
                    fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: members.length ? members.map((member)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "game-box py-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-white font-semibold",
                                children: member.name
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                                lineNumber: 22,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs text-slate-400",
                                children: member.userId === hostUserId ? 'Host' : ''
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                                lineNumber: 24,
                                columnNumber: 15
                            }, this)
                        ]
                    }, member.userId, true, {
                        fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                        lineNumber: 21,
                        columnNumber: 13
                    }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "game-box py-2",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-slate-300",
                        children: "No members yet (or still loading)..."
                    }, void 0, false, {
                        fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                        lineNumber: 31,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                    lineNumber: 30,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/lobby/LobbyMembersList.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/lobby/LobbyMembersList.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = LobbyMembersList;
var _c;
__turbopack_context__.k.register(_c, "LobbyMembersList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/models/roles.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ROLES",
    ()=>ROLES,
    "ROLE_NAMES",
    ()=>ROLE_NAMES,
    "VILLAGE_ROLES_BY_CATEGORY",
    ()=>VILLAGE_ROLES_BY_CATEGORY,
    "VILLAGE_ROLE_NAMES",
    ()=>VILLAGE_ROLE_NAMES,
    "getRoleDisplayName",
    ()=>getRoleDisplayName
]);
const getRoleDisplayName = (roleName)=>{
    if (roleName === 'AlphaWolf') return 'Alpha Wolf';
    return roleName;
};
const ROLES = {
    Villager: {
        faction: 'Village',
        category: 'Basic',
        ability: 'No special ability.',
        nightInstruction: 'You have no night action. Discuss and vote during the day.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'A steady voice in the dark. Read the room, sway the vote, and expose the pack.'
    },
    Werewolf: {
        faction: 'Enemy',
        category: 'Killing',
        ability: 'Coordinate at night and choose a player to eliminate.',
        nightInstruction: 'Choose a player to kill. Coordinate with other werewolves in secret chat.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Hide behind a friendly face by day, then hunt as one beneath the moon.'
    },
    AlphaWolf: {
        faction: 'Enemy',
        category: 'Killing',
        ability: "Choose the werewolves' kill target each night.",
        nightInstruction: "Choose the werewolves' kill target tonight. Coordinate with other werewolves in secret chat.",
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'You lead the hunt. Every night, your choice shapes who sees dawn.'
    },
    Framer: {
        faction: 'Enemy',
        category: 'Information',
        ability: 'Frame one player at night. Investigative results on them may appear suspicious.',
        nightInstruction: 'Choose a player to frame. Some investigative results on them may appear suspicious tonight.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Plant false clues and turn honest eyes toward the innocent.'
    },
    Prowler: {
        faction: 'Enemy',
        category: 'Information',
        ability: 'Prowl one player at night for clues on their role.',
        nightInstruction: 'Choose a player to prowl. You will receive a list of possible roles.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Quiet reconnaissance wins wars before the claws come out.'
    },
    Snatcher: {
        faction: 'Enemy',
        category: 'Control',
        ability: 'Snatch one player at night to roleblock them.',
        nightInstruction: 'Choose a player to snatch. Their night action (if any) will fail.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Drag key players off the board and watch plans unravel.'
    },
    Cursed: {
        faction: 'Enemy',
        category: 'Control',
        ability: 'Curse one player at night. Cursed players cannot be protected by a Doctor that night.',
        nightInstruction: 'Choose a player to curse. If a Doctor protects them tonight, the protection fails.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'A whisper of ruin that turns safety into false hope.'
    },
    Mimic: {
        faction: 'Enemy',
        category: 'Information',
        ability: 'Choose a player at night to mimic their role in village investigative checks.',
        nightInstruction: 'Choose a player to mimic. Village investigative checks may see you as their role.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Borrow a mask for the night and let suspicion land elsewhere.'
    },
    Doctor: {
        faction: 'Village',
        category: 'Support',
        ability: 'Choose a player at night to protect from a kill. You may protect yourself once per game.',
        nightInstruction: 'Choose a player to protect from a kill tonight. You may protect yourself once per game.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Keep hearts beating through the longest nights. Your protection can change everything.'
    },
    Tracker: {
        faction: 'Village',
        category: 'Information',
        ability: 'Choose a player at night to learn who they visited.',
        nightInstruction: 'Choose a player to track. You will learn who they visited.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Follow footprints in the dark and uncover who moves when no one should.'
    },
    Lookout: {
        faction: 'Village',
        category: 'Information',
        ability: 'Choose a player at night to see who visited them.',
        nightInstruction: 'Choose a player to watch. You will learn who visited them.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Watch the doors no one else watches. Witnesses decide who survives dawn.'
    },
    Investigator: {
        faction: 'Village',
        category: 'Information',
        ability: 'Investigate one player at night for clues on their role.',
        nightInstruction: 'Choose a player to investigate. You will receive a list of possible roles.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Piece together subtle tells and quiet lies to reveal the truth beneath the masks.'
    },
    Hunter: {
        faction: 'Village',
        category: 'Killing',
        ability: 'At night, choose a player to shoot (up to 3 shots total). If you kill a Village role, you die from guilt.',
        nightInstruction: ({ hunterShotsRemaining })=>(hunterShotsRemaining ?? 0) > 0 ? `Choose a player to shoot. Shots remaining: ${hunterShotsRemaining ?? 0}.` : 'You have no shots remaining tonight.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Justice rides with your rifle. Every shot matters, and every mistake has a price.'
    },
    Trapper: {
        faction: 'Village',
        category: 'Control',
        ability: 'At night, you may activate alert (up to 3 uses). Attackers who target you during alert are killed.',
        nightInstruction: ({ trapperAlertsRemaining, trapperAlertActive })=>trapperAlertActive ? 'Alert is active tonight.' : (trapperAlertsRemaining ?? 0) > 0 ? `Use "Activate Alert" to set a trap on yourself tonight. Alerts remaining: ${trapperAlertsRemaining ?? 0}.` : 'You have no alerts remaining tonight.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Set yourself as bait and spring the trap. Predators who strike carelessly may not return.'
    },
    Escort: {
        faction: 'Village',
        category: 'Control',
        ability: 'Roleblock one player at night so their action fails.',
        nightInstruction: 'Choose a player to roleblock so their night action fails.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Keep dangerous players occupied and throw enemy plans into disarray.'
    },
    Bodyguard: {
        faction: 'Village',
        category: 'Support',
        ability: 'Guard a player and intercept a hostile attack.',
        nightInstruction: 'Choose a player to guard. You will intercept a hostile attack aimed at them.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Stand between claw and kin. Your watch may be the wall that holds the village together.'
    },
    Jester: {
        faction: 'Neutral',
        category: 'Objective',
        ability: 'Cause chaos and attract suspicion.',
        nightInstruction: 'You have no night action. Try to get yourself executed during the day.',
        winCondition: 'Win by being executed by daytime vote.',
        revealSummary: 'Twist the town against you until they hand you victory at the gallows.'
    },
    Executioner: {
        faction: 'Neutral',
        category: 'Objective',
        ability: 'Has a specific target to push for execution. If that target dies at night, you become a Jester.',
        nightInstruction: 'You have no night action. Push your target during the day vote.',
        winCondition: 'Win if your assigned target is executed by vote.',
        revealSummary: 'Guide one chosen soul toward the noose; if fate steals them first, embrace chaos as Jester.'
    }
};
const ROLE_NAMES = Object.keys(ROLES);
_c = ROLE_NAMES;
const VILLAGE_ROLE_NAMES = ROLE_NAMES.filter(_c1 = (role)=>ROLES[role].faction === 'Village');
_c2 = VILLAGE_ROLE_NAMES;
const VILLAGE_ROLES_BY_CATEGORY = {
    Basic: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Basic'),
    Killing: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Killing'),
    Support: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Support'),
    Information: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Information'),
    Control: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Control')
};
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ROLE_NAMES");
__turbopack_context__.k.register(_c1, "VILLAGE_ROLE_NAMES$ROLE_NAMES.filter");
__turbopack_context__.k.register(_c2, "VILLAGE_ROLE_NAMES");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/lobby/DurationStepper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DurationStepper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function DurationStepper({ label, valueSeconds, minSeconds, isHost, onChange, formatSeconds }) {
    const canDecrease = valueSeconds > minSeconds;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center justify-between",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "game-section-title",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/lobby/DurationStepper.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "min-w-[4ch] text-center",
                        children: formatSeconds(valueSeconds)
                    }, void 0, false, {
                        fileName: "[project]/components/lobby/DurationStepper.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    isHost && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: [
                                    'px-2 py-1 rounded-md border transition',
                                    canDecrease ? 'border-slate-600/60 text-slate-200 hover:bg-slate-800/40' : 'border-slate-600/20 text-slate-200/40 cursor-not-allowed'
                                ].join(' '),
                                onClick: ()=>onChange(Math.max(minSeconds, valueSeconds - 30)),
                                disabled: !canDecrease,
                                "aria-label": `Decrease ${label.toLowerCase()} timer`,
                                children: "-"
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/DurationStepper.tsx",
                                lineNumber: 29,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "px-2 py-1 rounded-md border border-slate-600/60 text-slate-200 hover:bg-slate-800/40 transition",
                                onClick: ()=>onChange(valueSeconds + 30),
                                "aria-label": `Increase ${label.toLowerCase()} timer`,
                                children: "+"
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/DurationStepper.tsx",
                                lineNumber: 43,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/lobby/DurationStepper.tsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/lobby/DurationStepper.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/lobby/DurationStepper.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = DurationStepper;
var _c;
__turbopack_context__.k.register(_c, "DurationStepper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shared/InfoPopover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InfoPopover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
function InfoPopover({ ariaLabel, align = 'right', widthClassName = 'w-64', children }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InfoPopover.useEffect": ()=>{
            if (!open) return;
            const onPointerDown = {
                "InfoPopover.useEffect.onPointerDown": (event)=>{
                    const container = containerRef.current;
                    if (!container) return;
                    if (event.target instanceof Node && container.contains(event.target)) return;
                    setOpen(false);
                }
            }["InfoPopover.useEffect.onPointerDown"];
            document.addEventListener('pointerdown', onPointerDown, true);
            return ({
                "InfoPopover.useEffect": ()=>{
                    document.removeEventListener('pointerdown', onPointerDown, true);
                }
            })["InfoPopover.useEffect"];
        }
    }["InfoPopover.useEffect"], [
        open
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "relative inline-flex items-center z-40",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-label": ariaLabel,
                "aria-expanded": open,
                className: "inline-flex h-5 w-5 items-center justify-center rounded-full border border-slate-500/60 text-[11px] font-bold text-slate-200 hover:bg-slate-700/60 focus:outline-none focus:ring-2 focus:ring-sky-400",
                onKeyDown: (e)=>{
                    if (e.key === 'Escape') setOpen(false);
                },
                onClick: ()=>setOpen((prev)=>!prev),
                children: "i"
            }, void 0, false, {
                fileName: "[project]/components/shared/InfoPopover.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: [
                    'absolute top-full z-[999] mt-2 max-w-[calc(100vw-1rem)] rounded-md border border-slate-600 bg-slate-900/95 p-2 text-left text-xs text-slate-200 shadow-lg transition-opacity',
                    widthClassName,
                    align === 'left' ? 'left-1/2 -translate-x-1/2 sm:left-auto sm:translate-x-0 sm:right-0' : 'right-0',
                    open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
                ].join(' '),
                children: children
            }, void 0, false, {
                fileName: "[project]/components/shared/InfoPopover.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/shared/InfoPopover.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(InfoPopover, "c70JY9p7Da/HTz1NuXGWiUA9JHk=");
_c = InfoPopover;
var _c;
__turbopack_context__.k.register(_c, "InfoPopover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/lobby/RoleInfoPopover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RoleInfoPopover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/models/roles.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/shared/InfoPopover.tsx [app-client] (ecmascript)");
;
;
;
function RoleInfoPopover({ role, align = 'right' }) {
    const roleDisplayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRoleDisplayName"])(role);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ariaLabel: `${roleDisplayName} role info`,
        align: align,
        widthClassName: "w-64",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "leading-tight",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"][role].ability
            }, void 0, false, {
                fileName: "[project]/components/lobby/RoleInfoPopover.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 leading-tight text-amber-300",
                children: [
                    "Win: ",
                    __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"][role].winCondition
                ]
            }, void 0, true, {
                fileName: "[project]/components/lobby/RoleInfoPopover.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/lobby/RoleInfoPopover.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = RoleInfoPopover;
var _c;
__turbopack_context__.k.register(_c, "RoleInfoPopover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/formatters/timeFormatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Time Formatters

   Small, pure helpers so UI code doesn't re-implement:
   - "remaining seconds" rounding/clamping rules
   - `m:ss` formatting
============================================================================= */ /* ---------------------------------------------------------------------------
   getRemainingSecondsCeil(endsAtMs, nowMs)

   Converts two millisecond timestamps into a non-negative remaining seconds
   count. Uses `ceil` so "0.1s remaining" still displays as "1".
--------------------------------------------------------------------------- */ __turbopack_context__.s([
    "formatChatTimestamp",
    ()=>formatChatTimestamp,
    "formatMinutesSeconds",
    ()=>formatMinutesSeconds,
    "getRemainingSecondsCeil",
    ()=>getRemainingSecondsCeil
]);
const getRemainingSecondsCeil = (endsAtMs, nowMs)=>Math.max(0, Math.ceil((endsAtMs - nowMs) / 1000));
const formatMinutesSeconds = (totalSeconds)=>{
    const clamped = Math.max(0, Math.floor(totalSeconds));
    const minutes = Math.floor(clamped / 60);
    const seconds = clamped % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
};
const formatChatTimestamp = (sentAtMs)=>new Date(sentAtMs).toLocaleTimeString([], {
        hour: 'numeric',
        minute: '2-digit'
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/lobby/LobbySettings.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LobbySettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/models/roles.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$DurationStepper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/lobby/DurationStepper.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$RoleInfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/lobby/RoleInfoPopover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/formatters/timeFormatters.ts [app-client] (ecmascript)");
;
;
;
;
;
function LobbySettings({ isHost, werewolfCount, specialRolesEnabled, neutralRolesEnabled, phaseDurations, onWerewolfChange, onSpecialRolesEnabledChange, onNeutralRolesEnabledChange, onPhaseChange }) {
    const minWerewolves = specialRolesEnabled ? 2 : 1;
    const possibleRoles = Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"]).filter((role)=>role !== 'Villager' && role !== 'Werewolf' && (neutralRolesEnabled || __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"][role].faction !== 'Neutral'));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pt-1 space-y-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "game-label",
                        children: "Timers"
                    }, void 0, false, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$DurationStepper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: "Day",
                                valueSeconds: phaseDurations.daySeconds,
                                minSeconds: 10,
                                isHost: isHost,
                                onChange: (nextSeconds)=>onPhaseChange({
                                        ...phaseDurations,
                                        daySeconds: nextSeconds
                                    }),
                                formatSeconds: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatMinutesSeconds"]
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 33,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$DurationStepper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: "Night",
                                valueSeconds: phaseDurations.nightSeconds,
                                minSeconds: 10,
                                isHost: isHost,
                                onChange: (nextSeconds)=>onPhaseChange({
                                        ...phaseDurations,
                                        nightSeconds: nextSeconds
                                    }),
                                formatSeconds: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatMinutesSeconds"]
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 46,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$DurationStepper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                label: "Voting",
                                valueSeconds: phaseDurations.voteSeconds,
                                minSeconds: 10,
                                isHost: isHost,
                                onChange: (nextSeconds)=>onPhaseChange({
                                        ...phaseDurations,
                                        voteSeconds: nextSeconds
                                    }),
                                formatSeconds: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatMinutesSeconds"]
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 59,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/lobby/LobbySettings.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "game-label",
                children: "Roles"
            }, void 0, false, {
                fileName: "[project]/components/lobby/LobbySettings.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "game-box game-box-role flex items-start justify-between gap-3 py-3 sm:py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-semibold text-slate-100",
                                children: "Special Roles"
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-[11px] sm:text-xs text-slate-300/80 leading-snug",
                                children: "Adds special villager and werewolf roles."
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 82,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        role: "switch",
                        "aria-checked": specialRolesEnabled,
                        "aria-label": "Toggle special roles",
                        disabled: !isHost,
                        onClick: ()=>onSpecialRolesEnabledChange(!specialRolesEnabled),
                        className: [
                            'shrink-0 inline-flex h-8 w-16 sm:w-20 items-center rounded-full border p-1 transition',
                            specialRolesEnabled ? 'border-emerald-400/60 bg-emerald-500/20 text-emerald-100' : 'border-slate-500/50 bg-slate-700/30 text-slate-200',
                            specialRolesEnabled ? 'justify-end' : 'justify-start',
                            !isHost ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'
                        ].join(' '),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "h-6 w-6 shrink-0 rounded-full bg-white/90 transition"
                        }, void 0, false, {
                            fileName: "[project]/components/lobby/LobbySettings.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/lobby/LobbySettings.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            specialRolesEnabled ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "game-box game-box-role flex items-start justify-between gap-3 py-3 sm:py-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-semibold text-slate-100",
                                children: "Neutral Roles"
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 109,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-1 text-[11px] sm:text-xs text-slate-300/80 leading-snug",
                                children: "Adds neutral roles with unique win conditions."
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 112,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 108,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        role: "switch",
                        "aria-checked": neutralRolesEnabled,
                        "aria-label": "Toggle neutral roles",
                        disabled: !isHost,
                        onClick: ()=>onNeutralRolesEnabledChange(!neutralRolesEnabled),
                        className: [
                            'shrink-0 inline-flex h-8 w-16 sm:w-20 items-center rounded-full border p-1 transition',
                            neutralRolesEnabled ? 'border-emerald-400/60 bg-emerald-500/20 text-emerald-100' : 'border-slate-500/50 bg-slate-700/30 text-slate-200',
                            neutralRolesEnabled ? 'justify-end' : 'justify-start',
                            !isHost ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'
                        ].join(' '),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "h-6 w-6 shrink-0 rounded-full bg-white/90 transition"
                        }, void 0, false, {
                            fileName: "[project]/components/lobby/LobbySettings.tsx",
                            lineNumber: 132,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 116,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/lobby/LobbySettings.tsx",
                lineNumber: 107,
                columnNumber: 9
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "game-box game-box-werewolf py-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Werewolf"
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 139,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ml-auto flex items-center gap-3 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "min-w-[2ch] text-center",
                                        children: [
                                            "x",
                                            werewolfCount
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                                        lineNumber: 141,
                                        columnNumber: 13
                                    }, this),
                                    isHost && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: [
                                                    'px-2 py-1 rounded-md border transition',
                                                    werewolfCount > minWerewolves ? 'border-red-500/30 text-red-200 hover:bg-red-500/10' : 'border-red-500/10 text-red-200/40 cursor-not-allowed'
                                                ].join(' '),
                                                onClick: ()=>onWerewolfChange(Math.max(minWerewolves, werewolfCount - 1)),
                                                disabled: werewolfCount <= minWerewolves,
                                                "aria-label": "Decrease werewolf count",
                                                children: "-"
                                            }, void 0, false, {
                                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                                lineNumber: 144,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: "px-2 py-1 rounded-md border border-red-500/30 text-red-200 hover:bg-red-500/10 transition",
                                                onClick: ()=>onWerewolfChange(werewolfCount + 1),
                                                "aria-label": "Increase werewolf count",
                                                children: "+"
                                            }, void 0, false, {
                                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                                lineNumber: 160,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                                        lineNumber: 143,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 140,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 138,
                        columnNumber: 9
                    }, this),
                    specialRolesEnabled ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2 pt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs uppercase tracking-[0.2em] text-slate-300/80",
                                children: "Possible Roles"
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 175,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-2 overflow-visible",
                                children: possibleRoles.map((role, index)=>{
                                    const roleDisplayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRoleDisplayName"])(role);
                                    const align = index % 2 === 0 ? 'left' : 'right';
                                    const faction = __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"][role].faction;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: [
                                            'game-box py-2 relative overflow-visible hover:z-50 focus-within:z-50',
                                            faction === 'Neutral' ? 'bg-gradient-to-r from-slate-500/20 to-slate-700/20 border-slate-500/40 text-slate-200' : faction === 'Enemy' ? 'game-box-werewolf' : 'game-box-role'
                                        ].join(' '),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute right-2 top-1/2 -translate-y-1/2 z-30",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$RoleInfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    role: role,
                                                    align: align
                                                }, void 0, false, {
                                                    fileName: "[project]/components/lobby/LobbySettings.tsx",
                                                    lineNumber: 197,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                                lineNumber: 196,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "pr-8",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: roleDisplayName
                                                }, void 0, false, {
                                                    fileName: "[project]/components/lobby/LobbySettings.tsx",
                                                    lineNumber: 200,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                                lineNumber: 199,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, role, true, {
                                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                                        lineNumber: 185,
                                        columnNumber: 19
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/components/lobby/LobbySettings.tsx",
                                lineNumber: 178,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/lobby/LobbySettings.tsx",
                        lineNumber: 174,
                        columnNumber: 11
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/components/lobby/LobbySettings.tsx",
                lineNumber: 137,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/lobby/LobbySettings.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
_c = LobbySettings;
var _c;
__turbopack_context__.k.register(_c, "LobbySettings");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shared/Navbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Navbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function Navbar() {
    _s();
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "w-full px-4 py-4 sm:px-6 sm:py-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "game-title text-left leading-tight",
                children: "Nightfall in the Village"
            }, void 0, false, {
                fileName: "[project]/components/shared/Navbar.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            session ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex w-full items-center justify-between gap-3 sm:w-auto sm:justify-end sm:gap-6 sm:mr-6 min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-slate-200 font-semibold truncate min-w-0",
                        children: session.user?.name ?? session.user?.email
                    }, void 0, false, {
                        fileName: "[project]/components/shared/Navbar.tsx",
                        lineNumber: 16,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])(),
                        className: "sign-out-button",
                        children: "Sign out"
                    }, void 0, false, {
                        fileName: "[project]/components/shared/Navbar.tsx",
                        lineNumber: 19,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shared/Navbar.tsx",
                lineNumber: 15,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/components/shared/Navbar.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_s(Navbar, "xGqsfA9Yc4bug2CeORcyTsHwvXY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"]
    ];
});
_c = Navbar;
var _c;
__turbopack_context__.k.register(_c, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/useLobbyRealtime.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLobbyRealtime",
    ()=>useLobbyRealtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useLobbyRealtime(lobbyName) {
    _s();
    const [lobbyInfo, setLobbyInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyRealtime.useEffect": ()=>{
            if (!lobbyName) return;
            /* -------------------------------------------------------------------------
       Realtime Lobby State

       - `initiateLobby` returns the full current snapshot (reconnect-friendly)
       - `update` pushes snapshots as the server mutates the lobby
    ------------------------------------------------------------------------- */ let active = true;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
            const requestSnapshot = {
                "useLobbyRealtime.useEffect.requestSnapshot": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].emit('initiateLobby', {
                        lobbyName
                    }, {
                        "useLobbyRealtime.useEffect.requestSnapshot": (response)=>{
                            if (!active) return;
                            if (!response?.ok) {
                                // If the server restarted, in-memory lobbies are lost. Clear local state so
                                // UI doesn't keep rendering stale lobby info.
                                setLobbyInfo(null);
                                return;
                            }
                            setLobbyInfo(response.lobbyInfo);
                        }
                    }["useLobbyRealtime.useEffect.requestSnapshot"]);
                }
            }["useLobbyRealtime.useEffect.requestSnapshot"];
            // Initial snapshot (and used again on reconnect). Only emit once connected to
            // avoid queuing a snapshot request *and* also re-requesting on "connect".
            if (__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].connected) {
                requestSnapshot();
            }
            const onUpdate = {
                "useLobbyRealtime.useEffect.onUpdate": (data)=>{
                    if (!active) return;
                    setLobbyInfo(data);
                }
            }["useLobbyRealtime.useEffect.onUpdate"];
            /* -----------------------------------------------------------------------
       Reconnect Resilience

       When the socket reconnects (after a server restart or transient network
       issue), re-request the authoritative lobby snapshot.
    ----------------------------------------------------------------------- */ __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].on('connect', requestSnapshot);
            /* -----------------------------------------------------------------------
       Server Push Subscription: `update`

       Payload: full `LobbyView` snapshot.
       Why: keeps lobby pages in sync without polling.
       Cleanup: remove listener on unmount / lobby change.
    ----------------------------------------------------------------------- */ __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].on('update', onUpdate);
            return ({
                "useLobbyRealtime.useEffect": ()=>{
                    active = false;
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].off('connect', requestSnapshot);
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].off('update', onUpdate);
                }
            })["useLobbyRealtime.useEffect"];
        }
    }["useLobbyRealtime.useEffect"], [
        lobbyName
    ]);
    return {
        lobbyInfo,
        setLobbyInfo
    };
}
_s(useLobbyRealtime, "Ymx/JLsCIk0pSOgvJmchFBHIqmw=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/usePresenceView.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePresenceView",
    ()=>usePresenceView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/utils.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function usePresenceView(lobbyName, view) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePresenceView.useEffect": ()=>{
            if (!lobbyName) return;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
            // Idempotent: the server treats this as a state update (not a "do once" action).
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].emit('presence:setView', {
                lobbyName,
                view
            });
        }
    }["usePresenceView.useEffect"], [
        lobbyName,
        view
    ]);
}
_s(usePresenceView, "OD7bBpZva5O2jO+Puf00hKivP7c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/useNowTicker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useNowTicker",
    ()=>useNowTicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useNowTicker(enabled, intervalMs = 250) {
    _s();
    const [nowMs, setNowMs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useNowTicker.useEffect": ()=>{
            if (!enabled) {
                const resetId = setTimeout({
                    "useNowTicker.useEffect.resetId": ()=>{
                        setNowMs(null);
                    }
                }["useNowTicker.useEffect.resetId"], 0);
                return ({
                    "useNowTicker.useEffect": ()=>clearTimeout(resetId)
                })["useNowTicker.useEffect"];
            }
            const kickoffId = setTimeout({
                "useNowTicker.useEffect.kickoffId": ()=>{
                    setNowMs(Date.now());
                }
            }["useNowTicker.useEffect.kickoffId"], 0);
            const id = setInterval({
                "useNowTicker.useEffect.id": ()=>{
                    setNowMs(Date.now());
                }
            }["useNowTicker.useEffect.id"], intervalMs);
            return ({
                "useNowTicker.useEffect": ()=>{
                    clearTimeout(kickoffId);
                    clearInterval(id);
                }
            })["useNowTicker.useEffect"];
        }
    }["useNowTicker.useEffect"], [
        enabled,
        intervalMs
    ]);
    return nowMs;
}
_s(useNowTicker, "BXeI7xx2+8P3yftLpVRBBep4Ntg=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/socket/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Socket Constants

   Shared defaults for Socket.IO emit/ack behaviors.
============================================================================= */ /* ---------------------------------------------------------------------------
   SOCKET_ACK_TIMEOUT_MS

   Default timeout for request/ack events where the server is expected to reply.
--------------------------------------------------------------------------- */ __turbopack_context__.s([
    "SOCKET_ACK_TIMEOUT_MS",
    ()=>SOCKET_ACK_TIMEOUT_MS
]);
const SOCKET_ACK_TIMEOUT_MS = 5000;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/actions/lobbySocketActions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createLobby",
    ()=>createLobby,
    "joinLobby",
    ()=>joinLobby,
    "leaveLobby",
    ()=>leaveLobby,
    "requestLobbiesList",
    ()=>requestLobbiesList,
    "startGame",
    ()=>startGame,
    "updateLobbySettings",
    ()=>updateLobbySettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/constants.ts [app-client] (ecmascript)");
'use client';
;
;
;
const requestLobbiesList = (callback)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].timeout(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SOCKET_ACK_TIMEOUT_MS"]).emit('lobbiesList', {}, callback);
};
const joinLobby = (lobbyName, callback)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].timeout(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SOCKET_ACK_TIMEOUT_MS"]).emit('joinLobby', {
        lobbyName
    }, callback);
};
const createLobby = (lobbyName, callback)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].timeout(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SOCKET_ACK_TIMEOUT_MS"]).emit('createLobby', {
        lobbyName
    }, callback);
};
const leaveLobby = (lobbyName)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].emit('leaveLobby', {
        lobbyName
    });
};
const startGame = (lobbyName, callback)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].timeout(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SOCKET_ACK_TIMEOUT_MS"]).emit('startGame', {
        lobbyName
    }, callback);
};
const updateLobbySettings = (lobbyName, next, callback)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].timeout(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SOCKET_ACK_TIMEOUT_MS"]).emit('lobby:updateSettings', {
        lobbyName,
        ...next
    }, callback);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/selectors/lobbyUiSelectors.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_PHASE_DURATIONS",
    ()=>DEFAULT_PHASE_DURATIONS,
    "buildLobbySettingsPayload",
    ()=>buildLobbySettingsPayload,
    "getMinWerewolves",
    ()=>getMinWerewolves,
    "getStartingRemainingSeconds",
    ()=>getStartingRemainingSeconds
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/formatters/timeFormatters.ts [app-client] (ecmascript)");
'use client';
;
const DEFAULT_PHASE_DURATIONS = {
    daySeconds: 10,
    nightSeconds: 10,
    voteSeconds: 10
};
const getMinWerewolves = (specialRolesEnabled)=>specialRolesEnabled ? 2 : 1;
const getStartingRemainingSeconds = (startingAt, nowMs)=>startingAt && nowMs !== null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRemainingSecondsCeil"])(startingAt, nowMs) : null;
const buildLobbySettingsPayload = (lobbyInfo, overrides = {})=>{
    const nextSpecial = overrides.specialRolesEnabled ?? lobbyInfo.specialRolesEnabled ?? false;
    const nextNeutralRaw = overrides.neutralRolesEnabled ?? lobbyInfo.neutralRolesEnabled ?? false;
    // Neutral roles are only available when special roles are enabled.
    const nextNeutral = nextSpecial ? nextNeutralRaw : false;
    const minWerewolves = getMinWerewolves(nextSpecial);
    const desiredWerewolves = overrides.werewolfCount ?? lobbyInfo.werewolfCount ?? minWerewolves;
    const nextWerewolves = Math.max(minWerewolves, desiredWerewolves);
    return {
        werewolfCount: nextWerewolves,
        specialRolesEnabled: nextSpecial,
        neutralRolesEnabled: nextNeutral,
        phaseDurations: overrides.phaseDurations ?? lobbyInfo.phaseDurations ?? DEFAULT_PHASE_DURATIONS
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/routes/routePaths.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Route Path Helpers

   Small helpers for building internal app routes consistently.
   Centralizes `encodeURIComponent` so it isn't repeated across pages/hooks.
============================================================================= */ /* ---------------------------------------------------------------------------
   Lobby Routes
--------------------------------------------------------------------------- */ /* ---------------------------------------------------------------------------
   lobbyPath(lobbyName)

   Base lobby route for a given lobby name.
--------------------------------------------------------------------------- */ __turbopack_context__.s([
    "gamePath",
    ()=>gamePath,
    "lobbyPath",
    ()=>lobbyPath,
    "resultsPath",
    ()=>resultsPath
]);
const lobbyPath = (lobbyName)=>`/lobby/${encodeURIComponent(lobbyName)}`;
const gamePath = (lobbyName)=>`${lobbyPath(lobbyName)}/game`;
const resultsPath = (lobbyName)=>`${lobbyPath(lobbyName)}/results`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/routes/lobbyName.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Lobby Name Normalization (Client)

   Next.js route params are usually decoded, but in practice we can still see
   URL-encoded lobby names (or even double-encoded names) depending on how a
   user navigated (copy/paste, redirects, manual edits).

   If the client emits the wrong lobby key (ex: "My%2520Lobby"), the server will
   fail to find the lobby and return "Lobby does not exist".

   This helper gives pages/hooks a single, predictable way to derive the
   canonical lobby key from a route param.
============================================================================= */ __turbopack_context__.s([
    "normalizeLobbyNameParam",
    ()=>normalizeLobbyNameParam
]);
const normalizeLobbyNameParam = (value)=>{
    if (typeof value !== 'string') return undefined;
    let next = value;
    // Guard against double-encoding (ex: "%2520" -> "%20" -> " ").
    for(let i = 0; i < 2; i++){
        if (!next.includes('%')) break;
        try {
            const decoded = decodeURIComponent(next);
            if (decoded === next) break;
            next = decoded;
        } catch  {
            break;
        }
    }
    const trimmed = next.trim();
    return trimmed || undefined;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lobby/[lobbyName]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Lobby
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbyHeaderStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/lobby/LobbyHeaderStatus.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbyMembersList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/lobby/LobbyMembersList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbySettings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/lobby/LobbySettings.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$Navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/shared/Navbar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyRealtime$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useLobbyRealtime.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$usePresenceView$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/usePresenceView.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useNowTicker.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$lobbySocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/actions/lobbySocketActions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/selectors/lobbyUiSelectors.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$routePaths$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/routes/routePaths.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$lobbyName$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/routes/lobbyName.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Lobby() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { data: session, status: sessionStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"])();
    const { lobbyName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const lobbyNameParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$lobbyName$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeLobbyNameParam"])(typeof lobbyName === 'string' ? lobbyName : undefined);
    const { lobbyInfo, setLobbyInfo } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyRealtime$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLobbyRealtime"])(lobbyNameParam);
    /* -----------------------------------------------------------------------
     Lobby Name (Canonical)

     Prefer the server-provided lobby name once we have a snapshot. This avoids
     edge cases where the URL param is encoded/decoded differently (ex: spaces).
  ----------------------------------------------------------------------- */ const lobbyNameCanonical = lobbyInfo?.lobbyName ?? lobbyNameParam;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Lobby.useEffect": ()=>{
            /* -----------------------------------------------------------------------
       Lobby -> Game Redirect

       The lobby view is only for pre-game setup. Once the server marks the
       lobby as started, we immediately route into `/game` (unless the lobby is
       already in the end/results phases).
    ----------------------------------------------------------------------- */ if (!lobbyInfo?.started) return;
            const name = lobbyInfo?.lobbyName ?? lobbyNameCanonical;
            if (!name) return;
            if (lobbyInfo.gamePhase === 'endGame' || lobbyInfo.gamePhase === 'gameResults') {
                return;
            }
            router.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$routePaths$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gamePath"])(name));
        }
    }["Lobby.useEffect"], [
        lobbyInfo?.started,
        lobbyInfo?.lobbyName,
        lobbyInfo?.gamePhase,
        lobbyNameCanonical,
        router
    ]);
    /* -----------------------------------------------------------------------
     Countdown Ticker

     `startingAt` is a server timestamp. We keep a short interval clock so the
     UI can render a smooth "Starting in..." countdown without server spam.
  ----------------------------------------------------------------------- */ const nowMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNowTicker"])(!!lobbyInfo?.startingAt, 250);
    /* -----------------------------------------------------------------------
     Presence Tracking

     Lets the server know the user is actively viewing the lobby screen.
  ----------------------------------------------------------------------- */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$usePresenceView$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePresenceView"])(lobbyNameCanonical, 'lobby');
    /* -----------------------------------------------------------------------
     Derived Display Values
  ----------------------------------------------------------------------- */ const startingRemainingSeconds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStartingRemainingSeconds"])(lobbyInfo?.startingAt, nowMs);
    const settingsDisplay = lobbyInfo ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLobbySettingsPayload"])(lobbyInfo) : null;
    /* -----------------------------------------------------------------------
     Host Permissions

     Host-only controls (settings + start game).
  ----------------------------------------------------------------------- */ const isHost = lobbyInfo?.hostUserId && session?.user?.id ? lobbyInfo.hostUserId === session.user.id : false;
    const [settingsOpen, setSettingsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const applyLobbySettings = (next)=>{
        /* -----------------------------------------------------------------------
       Host Settings Updates

       `useLobbyRealtime` keeps us in sync with the server. We still optimistically
       merge the successful update into local state so the UI reacts immediately.
    ----------------------------------------------------------------------- */ if (!lobbyNameCanonical) return;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$lobbySocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateLobbySettings"])(lobbyNameCanonical, next, (err, res)=>{
            if (err || !res?.ok) {
                console.error(res?.error ?? 'Failed to update lobby settings');
                return;
            }
            setLobbyInfo((prev)=>prev ? {
                    ...prev,
                    ...next
                } : prev);
        });
    };
    const handleWerewolfChange = (count)=>{
        if (!lobbyInfo) return;
        applyLobbySettings((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLobbySettingsPayload"])(lobbyInfo, {
            werewolfCount: count
        }));
    };
    const handleSpecialRolesEnabledChange = (enabled)=>{
        if (!lobbyInfo) return;
        applyLobbySettings((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLobbySettingsPayload"])(lobbyInfo, {
            specialRolesEnabled: enabled
        }));
    };
    const handleNeutralRolesEnabledChange = (enabled)=>{
        if (!lobbyInfo) return;
        applyLobbySettings((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLobbySettingsPayload"])(lobbyInfo, {
            neutralRolesEnabled: enabled
        }));
    };
    const handlePhaseChange = (next)=>{
        if (!lobbyInfo) return;
        applyLobbySettings((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildLobbySettingsPayload"])(lobbyInfo, {
            phaseDurations: next
        }));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$Navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                lineNumber: 161,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-h-[100svh] flex flex-col items-center px-4 py-4 sm:px-6 sm:py-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full max-w-6xl",
                    children: [
                        lobbyInfo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbyHeaderStatus$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            lobbyName: lobbyInfo.lobbyName,
                            started: lobbyInfo.started,
                            startingRemainingSeconds: startingRemainingSeconds
                        }, void 0, false, {
                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                            lineNumber: 165,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4 mb-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "game-title text-left",
                                children: "Loading Lobby..."
                            }, void 0, false, {
                                fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                lineNumber: 172,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                            lineNumber: 171,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-4 lg:flex-row lg:items-stretch lg:gap-6 lg:min-h-[calc(100svh-12rem)]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full lg:w-1/3 flex flex-col gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbyMembersList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            members: lobbyInfo?.members ?? [],
                                            hostUserId: lobbyInfo?.hostUserId ?? ''
                                        }, void 0, false, {
                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                            lineNumber: 178,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "hidden lg:block pt-2 space-y-2 mt-auto",
                                            children: [
                                                sessionStatus === 'loading' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-xs text-slate-400",
                                                    children: "Checking session..."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 185,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: "game-button-secondary",
                                                    onClick: ()=>{
                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$lobbySocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["leaveLobby"])(lobbyName);
                                                        router.push('/');
                                                    },
                                                    children: "Leave Lobby"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 189,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                            lineNumber: 183,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                    lineNumber: 177,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden lg:block lg:self-stretch w-px bg-gradient-to-b from-transparent via-sky-400/60 to-transparent"
                                }, void 0, false, {
                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                    lineNumber: 202,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full lg:w-2/3 lg:pl-6 flex flex-col",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "lg:hidden",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    className: "w-full py-2 flex items-center justify-between gap-3 border-b border-slate-700/70",
                                                    "aria-expanded": settingsOpen,
                                                    onClick: ()=>setSettingsOpen((prev)=>!prev),
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "game-section-title text-slate-300",
                                                            children: "Settings"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                            lineNumber: 212,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs font-semibold text-slate-400",
                                                            children: settingsOpen ? 'Hide' : 'Show'
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                            lineNumber: 215,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 206,
                                                    columnNumber: 17
                                                }, this),
                                                settingsOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-4 space-y-4",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbySettings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        isHost: isHost,
                                                        werewolfCount: settingsDisplay?.werewolfCount ?? 1,
                                                        specialRolesEnabled: settingsDisplay?.specialRolesEnabled ?? false,
                                                        neutralRolesEnabled: settingsDisplay?.neutralRolesEnabled ?? false,
                                                        phaseDurations: settingsDisplay?.phaseDurations ?? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PHASE_DURATIONS"],
                                                        onWerewolfChange: handleWerewolfChange,
                                                        onSpecialRolesEnabledChange: handleSpecialRolesEnabledChange,
                                                        onNeutralRolesEnabledChange: handleNeutralRolesEnabledChange,
                                                        onPhaseChange: handlePhaseChange
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                        lineNumber: 222,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 221,
                                                    columnNumber: 19
                                                }, this) : null,
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "pt-4 space-y-2",
                                                    children: [
                                                        sessionStatus === 'loading' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-slate-400",
                                                            children: "Checking session..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                            lineNumber: 238,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            className: "game-button-secondary",
                                                            onClick: ()=>{
                                                                if (!lobbyNameCanonical) return;
                                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$lobbySocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["leaveLobby"])(lobbyNameCanonical);
                                                                router.push('/');
                                                            },
                                                            children: "Leave Lobby"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                            lineNumber: 242,
                                                            columnNumber: 19
                                                        }, this),
                                                        isHost && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            className: "game-button-primary disabled:opacity-60 disabled:cursor-not-allowed",
                                                            disabled: !lobbyInfo || lobbyInfo.started || lobbyInfo.startingAt !== null,
                                                            onClick: ()=>{
                                                                if (!lobbyNameCanonical) return;
                                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$lobbySocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startGame"])(lobbyNameCanonical, (err, res)=>{
                                                                    if (err || !res?.ok) {
                                                                        console.error(res?.error ?? 'Failed to start game');
                                                                    }
                                                                });
                                                            },
                                                            children: lobbyInfo?.startingAt !== null ? 'Starting...' : lobbyInfo?.started ? 'Game Started' : 'Start Game'
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                            lineNumber: 254,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 236,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                            lineNumber: 205,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "hidden lg:flex lg:flex-col lg:flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "game-section-title",
                                                        children: "Settings"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                        lineNumber: 283,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 282,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-4",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbySettings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        isHost: isHost,
                                                        werewolfCount: settingsDisplay?.werewolfCount ?? 1,
                                                        specialRolesEnabled: settingsDisplay?.specialRolesEnabled ?? false,
                                                        neutralRolesEnabled: settingsDisplay?.neutralRolesEnabled ?? false,
                                                        phaseDurations: settingsDisplay?.phaseDurations ?? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PHASE_DURATIONS"],
                                                        onWerewolfChange: handleWerewolfChange,
                                                        onSpecialRolesEnabledChange: handleSpecialRolesEnabledChange,
                                                        onNeutralRolesEnabledChange: handleNeutralRolesEnabledChange,
                                                        onPhaseChange: handlePhaseChange
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                        lineNumber: 287,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 286,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "pt-4 space-y-2 mt-auto",
                                                    children: [
                                                        sessionStatus === 'loading' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-slate-400",
                                                            children: "Checking session..."
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                            lineNumber: 302,
                                                            columnNumber: 21
                                                        }, this),
                                                        isHost && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            className: "game-button-primary disabled:opacity-60 disabled:cursor-not-allowed",
                                                            disabled: !lobbyInfo || lobbyInfo.started || lobbyInfo.startingAt !== null,
                                                            onClick: ()=>{
                                                                if (!lobbyNameCanonical) return;
                                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$lobbySocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startGame"])(lobbyNameCanonical, (err, res)=>{
                                                                    if (err || !res?.ok) {
                                                                        console.error(res?.error ?? 'Failed to start game');
                                                                    }
                                                                });
                                                            },
                                                            children: lobbyInfo?.startingAt !== null ? 'Starting...' : lobbyInfo?.started ? 'Game Started' : 'Start Game'
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                            lineNumber: 307,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                                    lineNumber: 300,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                            lineNumber: 281,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                                    lineNumber: 204,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                    lineNumber: 163,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/page.tsx",
                lineNumber: 162,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Lobby, "2SBY+UiDlI+T9C1otCtWG9iK2ZM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyRealtime$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLobbyRealtime"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNowTicker"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$usePresenceView$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePresenceView"]
    ];
});
_c = Lobby;
var _c;
__turbopack_context__.k.register(_c, "Lobby");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_856f5998._.js.map