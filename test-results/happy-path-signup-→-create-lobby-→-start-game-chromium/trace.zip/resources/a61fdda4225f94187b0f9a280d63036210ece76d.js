(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/socket/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "socket",
    ()=>socket
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/socket.io-client/build/esm/index.js [app-client] (ecmascript) <locals>");
'use client';
;
/* =============================================================================
   Socket.IO Client

   Default behavior is to connect to the same origin (recommended for deployments).
   You can override via `NEXT_PUBLIC_SOCKET_URL` for local/remote testing.
============================================================================= */ const SOCKET_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_SOCKET_URL;
const socket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["io"])(SOCKET_URL, {
    autoConnect: false
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/socket/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "connectSocketIfNeeded",
    ()=>connectSocketIfNeeded
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
'use client';
;
const connectSocketIfNeeded = ()=>{
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].connected) __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].connect();
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/lobby/LobbySessionGuard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LobbySessionGuard",
    ()=>LobbySessionGuard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function LobbySessionGuard({ children }) {
    _s();
    const { lobbyName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { status } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LobbySessionGuard.useEffect": ()=>{
            if (status === 'loading') return;
            /* -------------------------------------------------------------------------
       Auth gate
    ------------------------------------------------------------------------- */ if (status === 'unauthenticated') {
                router.replace('/');
                return;
            }
            /* -------------------------------------------------------------------------
       Lobby gate
    ------------------------------------------------------------------------- */ if (!lobbyName) return;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
            const verifyLobby = {
                "LobbySessionGuard.useEffect.verifyLobby": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].emit('lobby:verify', {
                        lobbyName
                    }, {
                        "LobbySessionGuard.useEffect.verifyLobby": (res)=>{
                            if (!res?.ok) {
                                router.replace('/');
                            }
                        }
                    }["LobbySessionGuard.useEffect.verifyLobby"]);
                }
            }["LobbySessionGuard.useEffect.verifyLobby"];
            // Fast-fail if the socket can't connect in a reasonable time.
            const timeoutId = setTimeout({
                "LobbySessionGuard.useEffect.timeoutId": ()=>{
                    if (!__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].connected) {
                        router.replace('/');
                    }
                }
            }["LobbySessionGuard.useEffect.timeoutId"], 2000);
            // Initial verify + re-verify on reconnect (server restarts wipe in-memory state).
            verifyLobby();
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].on('connect', verifyLobby);
            return ({
                "LobbySessionGuard.useEffect": ()=>{
                    clearTimeout(timeoutId);
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].off('connect', verifyLobby);
                }
            })["LobbySessionGuard.useEffect"];
        }
    }["LobbySessionGuard.useEffect"], [
        lobbyName,
        router,
        status
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(LobbySessionGuard, "zQ5SdK+WRAQ+KUZuWYIBKIKcOHw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"]
    ];
});
_c = LobbySessionGuard;
var _c;
__turbopack_context__.k.register(_c, "LobbySessionGuard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lobby/[lobbyName]/layout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LobbyLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbySessionGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/lobby/LobbySessionGuard.tsx [app-client] (ecmascript)");
'use client';
;
;
function LobbyLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$lobby$2f$LobbySessionGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LobbySessionGuard"], {
        children: children
    }, void 0, false, {
        fileName: "[project]/app/lobby/[lobbyName]/layout.tsx",
        lineNumber: 17,
        columnNumber: 10
    }, this);
}
_c = LobbyLayout;
var _c;
__turbopack_context__.k.register(_c, "LobbyLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_3a0d70d1._.js.map