(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/game/EliminationResultsCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EliminationResultsCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function EliminationResultsCard({ currentPhase, eliminationResultsKey, eliminationResult }) {
    if (currentPhase !== 'eliminationResults') return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "game-box result-scene-card flex-col items-start gap-3 text-left",
        children: eliminationResult?.noElimination === true ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "result-line-1 text-slate-200 font-semibold",
            children: "No player was eliminated today."
        }, void 0, false, {
            fileName: "[project]/components/game/EliminationResultsCard.tsx",
            lineNumber: 24,
            columnNumber: 11
        }, this) : eliminationResult ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "result-line-1 text-red-200 font-semibold",
                    children: [
                        eliminationResult.name,
                        " was executed by the town (",
                        eliminationResult.voteCount,
                        " votes)."
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/game/EliminationResultsCard.tsx",
                    lineNumber: 31,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "result-line-2 text-slate-300 text-sm",
                    children: eliminationResult.notebook.trim() ? 'We found a will next to their body.' : 'We could not find a last will.'
                }, void 0, false, {
                    fileName: "[project]/components/game/EliminationResultsCard.tsx",
                    lineNumber: 34,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "result-line-3 w-full rounded-lg border border-slate-700 bg-slate-950/80 p-3 text-sm text-slate-200 whitespace-pre-wrap",
                    children: eliminationResult.notebook.trim() || 'No final notes were left behind.'
                }, void 0, false, {
                    fileName: "[project]/components/game/EliminationResultsCard.tsx",
                    lineNumber: 39,
                    columnNumber: 15
                }, this)
            ]
        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "result-line-1 text-slate-200 font-semibold",
            children: "Awaiting verdict..."
        }, void 0, false, {
            fileName: "[project]/components/game/EliminationResultsCard.tsx",
            lineNumber: 45,
            columnNumber: 13
        }, this)
    }, eliminationResultsKey, false, {
        fileName: "[project]/components/game/EliminationResultsCard.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = EliminationResultsCard;
var _c;
__turbopack_context__.k.register(_c, "EliminationResultsCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/EndGameScene.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EndGameScene
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function EndGameScene({ didWin, winningFaction, endGameButton }) {
    const outcome = winningFaction ?? 'Village';
    const { title, subtitle } = (()=>{
        if (outcome === 'Executioner') {
            return {
                title: 'Executioner Wins',
                subtitle: didWin === true ? 'Your target was executed by vote.' : didWin === false ? 'A target was executed by vote. The Executioner claims victory.' : 'A target was executed by vote.'
            };
        }
        if (outcome === 'Jester') {
            return {
                title: 'Jester Wins',
                subtitle: didWin === true ? 'You were executed by vote. Chaos wins.' : didWin === false ? 'The Jester was executed by vote. Chaos wins.' : 'A Jester was executed by vote.'
            };
        }
        if (outcome === 'Enemy') {
            return {
                title: 'Werewolves Win',
                subtitle: didWin === true ? 'The village has fallen. You prevailed.' : didWin === false ? 'The village has fallen. You did not prevail.' : 'The village has fallen.'
            };
        }
        return {
            title: 'Villagers Win',
            subtitle: didWin === true ? 'The last werewolf has fallen. You survived.' : didWin === false ? 'The last werewolf has fallen. You did not prevail.' : 'The last werewolf has fallen.'
        };
    })();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "game-cinematic-scene min-h-[100svh] flex items-center justify-center px-4 sm:px-6 py-10 sm:py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-3xl text-center space-y-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "reveal-prefix",
                    children: "Game Over"
                }, void 0, false, {
                    fileName: "[project]/components/game/EndGameScene.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: [
                        'text-5xl md:text-6xl font-black uppercase tracking-[0.06em]',
                        didWin === true ? 'text-emerald-300' : didWin === false ? 'text-red-400' : 'text-slate-200'
                    ].join(' '),
                    children: title
                }, void 0, false, {
                    fileName: "[project]/components/game/EndGameScene.tsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "reveal-subtitle",
                    children: subtitle
                }, void 0, false, {
                    fileName: "[project]/components/game/EndGameScene.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, this),
                endGameButton ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pt-4 max-w-xs mx-auto",
                    children: endGameButton
                }, void 0, false, {
                    fileName: "[project]/components/game/EndGameScene.tsx",
                    lineNumber: 82,
                    columnNumber: 11
                }, this) : null
            ]
        }, void 0, true, {
            fileName: "[project]/components/game/EndGameScene.tsx",
            lineNumber: 66,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/EndGameScene.tsx",
        lineNumber: 65,
        columnNumber: 5
    }, this);
}
_c = EndGameScene;
var _c;
__turbopack_context__.k.register(_c, "EndGameScene");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/socket/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Socket Constants

   Shared defaults for Socket.IO emit/ack behaviors.
============================================================================= */ /* ---------------------------------------------------------------------------
   SOCKET_ACK_TIMEOUT_MS

   Default timeout for request/ack events where the server is expected to reply.
--------------------------------------------------------------------------- */ __turbopack_context__.s([
    "SOCKET_ACK_TIMEOUT_MS",
    ()=>SOCKET_ACK_TIMEOUT_MS
]);
const SOCKET_ACK_TIMEOUT_MS = 5000;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/actions/gameSocketActions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bodyguardGuard",
    ()=>bodyguardGuard,
    "castVote",
    ()=>castVote,
    "curse",
    ()=>curse,
    "doctorProtect",
    ()=>doctorProtect,
    "endGame",
    ()=>endGame,
    "escortVisit",
    ()=>escortVisit,
    "frame",
    ()=>frame,
    "getNotebook",
    ()=>getNotebook,
    "initChat",
    ()=>initChat,
    "initGame",
    ()=>initGame,
    "investigate",
    ()=>investigate,
    "lookoutWatch",
    ()=>lookoutWatch,
    "mimic",
    ()=>mimic,
    "nightKill",
    ()=>nightKill,
    "prowl",
    ()=>prowl,
    "sendChatMessage",
    ()=>sendChatMessage,
    "snatch",
    ()=>snatch,
    "toggleTrapperAlert",
    ()=>toggleTrapperAlert,
    "trackerWatch",
    ()=>trackerWatch,
    "updateNotebook",
    ()=>updateNotebook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
/* =============================================================================
   Client -> Server Socket Actions

   Thin wrapper functions around `socket.emit(...)` so UI components:
   - stay readable
   - don't repeat event name strings everywhere
   - can rely on `connectSocketIfNeeded()` automatically
============================================================================= */ /* ---------------------------------------------------------------------------
   emit(...)

   Internal helper that:
   - connects the socket if needed
   - forwards `socket.emit` with its full overload surface
--------------------------------------------------------------------------- */ const emit = (...args)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].emit(...args);
};
const initGame = (lobbyName, callback)=>{
    emit('game:init', {
        lobbyName
    }, callback);
};
const endGame = (lobbyName, callback)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].timeout(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SOCKET_ACK_TIMEOUT_MS"]).emit('endGame', {
        lobbyName
    }, callback);
};
const nightKill = (lobbyName, targetUserId)=>{
    emit('game:nightKill', {
        lobbyName,
        targetUserId
    });
};
const toggleTrapperAlert = (lobbyName)=>{
    emit('game:toggleTrapperAlert', {
        lobbyName
    });
};
const escortVisit = (lobbyName, targetUserId)=>{
    emit('game:escortVisit', {
        lobbyName,
        targetUserId
    });
};
const bodyguardGuard = (lobbyName, targetUserId)=>{
    emit('game:bodyguardGuard', {
        lobbyName,
        targetUserId
    });
};
const doctorProtect = (lobbyName, targetUserId)=>{
    emit('game:doctorProtect', {
        lobbyName,
        targetUserId
    });
};
const trackerWatch = (lobbyName, targetUserId)=>{
    emit('game:trackerWatch', {
        lobbyName,
        targetUserId
    });
};
const lookoutWatch = (lobbyName, targetUserId)=>{
    emit('game:lookoutWatch', {
        lobbyName,
        targetUserId
    });
};
const investigate = (lobbyName, targetUserId)=>{
    emit('game:investigate', {
        lobbyName,
        targetUserId
    });
};
const frame = (lobbyName, targetUserId)=>{
    emit('game:frame', {
        lobbyName,
        targetUserId
    });
};
const prowl = (lobbyName, targetUserId)=>{
    emit('game:prowl', {
        lobbyName,
        targetUserId
    });
};
const snatch = (lobbyName, targetUserId)=>{
    emit('game:snatch', {
        lobbyName,
        targetUserId
    });
};
const curse = (lobbyName, targetUserId)=>{
    emit('game:curse', {
        lobbyName,
        targetUserId
    });
};
const mimic = (lobbyName, targetUserId)=>{
    emit('game:mimic', {
        lobbyName,
        targetUserId
    });
};
const castVote = (lobbyName, targetUserId)=>{
    emit('game:castVote', {
        lobbyName,
        targetUserId
    });
};
const updateNotebook = (lobbyName, notes)=>{
    emit('game:updateNotebook', {
        lobbyName,
        notes
    });
};
const getNotebook = (lobbyName, targetUserId, callback)=>{
    emit('game:getNotebook', {
        lobbyName,
        targetUserId
    }, callback);
};
const initChat = (lobbyName, callback)=>{
    emit('chat:init', {
        lobbyName
    }, callback);
};
const sendChatMessage = (lobbyName, channel, content, callback)=>{
    emit('chat:send', {
        lobbyName,
        channel,
        content
    }, callback);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/useMediaQuery.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMediaQuery",
    ()=>useMediaQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useMediaQuery(query, fallback = false) {
    _s();
    const [matches, setMatches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useMediaQuery.useState": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            return window.matchMedia(query).matches;
        }
    }["useMediaQuery.useState"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMediaQuery.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            const media = window.matchMedia(query);
            const update = {
                "useMediaQuery.useEffect.update": ()=>setMatches(media.matches)
            }["useMediaQuery.useEffect.update"];
            update();
            media.addEventListener('change', update);
            return ({
                "useMediaQuery.useEffect": ()=>{
                    media.removeEventListener('change', update);
                }
            })["useMediaQuery.useEffect"];
        }
    }["useMediaQuery.useEffect"], [
        query
    ]);
    return matches;
}
_s(useMediaQuery, "fNPvL0OrqDA5LDIifURA029FPAA=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/constants/uiConstants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   UI Constants

   Central place for shared UI "magic values" like breakpoints.
============================================================================= */ /* ---------------------------------------------------------------------------
   Breakpoints

   Keep breakpoint media queries centralized so components stay consistent.
--------------------------------------------------------------------------- */ /* ---------------------------------------------------------------------------
   DESKTOP_MEDIA_QUERY

   Tailwind `sm` breakpoint as a media query string (used with `matchMedia`).
--------------------------------------------------------------------------- */ __turbopack_context__.s([
    "DESKTOP_MEDIA_QUERY",
    ()=>DESKTOP_MEDIA_QUERY
]);
const DESKTOP_MEDIA_QUERY = '(min-width: 640px)';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/formatters/timeFormatters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Time Formatters

   Small, pure helpers so UI code doesn't re-implement:
   - "remaining seconds" rounding/clamping rules
   - `m:ss` formatting
============================================================================= */ /* ---------------------------------------------------------------------------
   getRemainingSecondsCeil(endsAtMs, nowMs)

   Converts two millisecond timestamps into a non-negative remaining seconds
   count. Uses `ceil` so "0.1s remaining" still displays as "1".
--------------------------------------------------------------------------- */ __turbopack_context__.s([
    "formatChatTimestamp",
    ()=>formatChatTimestamp,
    "formatMinutesSeconds",
    ()=>formatMinutesSeconds,
    "getRemainingSecondsCeil",
    ()=>getRemainingSecondsCeil
]);
const getRemainingSecondsCeil = (endsAtMs, nowMs)=>Math.max(0, Math.ceil((endsAtMs - nowMs) / 1000));
const formatMinutesSeconds = (totalSeconds)=>{
    const clamped = Math.max(0, Math.floor(totalSeconds));
    const minutes = Math.floor(clamped / 60);
    const seconds = clamped % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
};
const formatChatTimestamp = (sentAtMs)=>new Date(sentAtMs).toLocaleTimeString([], {
        hour: 'numeric',
        minute: '2-digit'
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/GameChat.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GameChat
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/actions/gameSocketActions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useMediaQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useMediaQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$uiConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/constants/uiConstants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/formatters/timeFormatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const CHANNEL_LABELS = {
    village: 'Village Chat'
};
function GameChat({ lobbyName, refreshKey, currentUserId }) {
    _s();
    const isDesktop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useMediaQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$uiConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DESKTOP_MEDIA_QUERY"]);
    const [mobileOpen, setMobileOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const isOpen = isDesktop ? true : mobileOpen;
    const [unreadCount, setUnreadCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [stickToBottom, setStickToBottom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [channels, setChannels] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [history, setHistory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [canSend, setCanSend] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [activeChannel, setActiveChannel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [draft, setDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const messagePaneRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const shouldStickToBottomRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameChat.useEffect": ()=>{
            if (!lobbyName) return;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initChat"])(lobbyName, {
                "GameChat.useEffect": (response)=>{
                    if (!response?.ok || !response.chat) {
                        setChannels([]);
                        setCanSend({});
                        setHistory({});
                        setActiveChannel(null);
                        return;
                    }
                    setChannels(response.chat.channels);
                    setCanSend(response.chat.canSend ?? {});
                    setHistory(response.chat.history ?? {});
                    setActiveChannel({
                        "GameChat.useEffect": (current)=>current && response.chat?.channels.includes(current) ? current : response.chat?.channels[0] ?? null
                    }["GameChat.useEffect"]);
                    setUnreadCount(0);
                }
            }["GameChat.useEffect"]);
        }
    }["GameChat.useEffect"], [
        lobbyName,
        refreshKey
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameChat.useEffect": ()=>{
            const onChatMessage = {
                "GameChat.useEffect.onChatMessage": (message, callback)=>{
                    setHistory({
                        "GameChat.useEffect.onChatMessage": (current)=>{
                            const nextMessages = [
                                ...current[message.channel] ?? [],
                                message
                            ];
                            return {
                                ...current,
                                [message.channel]: nextMessages
                            };
                        }
                    }["GameChat.useEffect.onChatMessage"]);
                    const isRelevantChannel = !activeChannel || message.channel === activeChannel;
                    const shouldCountAsUnread = isRelevantChannel && (!isDesktop && !isOpen || shouldStickToBottomRef.current === false);
                    if (shouldCountAsUnread) {
                        setUnreadCount({
                            "GameChat.useEffect.onChatMessage": (current)=>current + 1
                        }["GameChat.useEffect.onChatMessage"]);
                    }
                    callback?.({
                        ok: true
                    });
                }
            }["GameChat.useEffect.onChatMessage"];
            /* -----------------------------------------------------------------------
       Server Push Subscription: `chat:message`

       Payload: `ChatMessage` (plus optional ack callback).
       Why: keep the chat history realtime without polling.
       Cleanup: remove listener on unmount.
    ----------------------------------------------------------------------- */ __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].on('chat:message', onChatMessage);
            return ({
                "GameChat.useEffect": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].off('chat:message', onChatMessage);
                }
            })["GameChat.useEffect"];
        }
    }["GameChat.useEffect"], [
        activeChannel,
        isDesktop,
        isOpen
    ]);
    const activeMessages = activeChannel ? history[activeChannel] ?? [] : [];
    const activeChannelCanSend = activeChannel ? canSend[activeChannel] === true : false;
    const helperText = error ?? '';
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameChat.useEffect": ()=>{
            /* -----------------------------------------------------------------------
       Stick-To-Bottom Behavior

       While the user has not scrolled up, keep the scroll pane pinned to the
       bottom whenever the active channel changes or new messages arrive.
    ----------------------------------------------------------------------- */ const pane = messagePaneRef.current;
            if (!pane) return;
            if (shouldStickToBottomRef.current) {
                pane.scrollTop = pane.scrollHeight;
            }
        }
    }["GameChat.useEffect"], [
        activeChannel,
        activeMessages.length
    ]);
    if (!lobbyName || channels.length === 0) {
        return null;
    }
    if (!isDesktop && !isOpen) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            className: "fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] left-4 z-40 inline-flex h-12 items-center justify-center gap-2 rounded-full border border-slate-700 bg-slate-950/92 px-4 text-xs font-semibold text-slate-100 shadow-2xl backdrop-blur transition hover:bg-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/80",
            onClick: ()=>{
                setMobileOpen(true);
                setUnreadCount(0);
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    children: "Chat"
                }, void 0, false, {
                    fileName: "[project]/components/game/GameChat.tsx",
                    lineNumber: 137,
                    columnNumber: 9
                }, this),
                unreadCount > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "inline-flex min-w-5 items-center justify-center rounded-full bg-amber-400 px-1.5 py-0.5 text-[10px] font-black text-slate-900",
                    children: unreadCount > 99 ? '99+' : unreadCount
                }, void 0, false, {
                    fileName: "[project]/components/game/GameChat.tsx",
                    lineNumber: 139,
                    columnNumber: 11
                }, this) : null
            ]
        }, void 0, true, {
            fileName: "[project]/components/game/GameChat.tsx",
            lineNumber: 129,
            columnNumber: 7
        }, this);
    }
    const submitMessage = ()=>{
        if (!lobbyName || !activeChannel) return;
        if (!activeChannelCanSend) return;
        const trimmedDraft = draft.trim();
        if (!trimmedDraft) return;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sendChatMessage"])(lobbyName, activeChannel, trimmedDraft, (response)=>{
            if (!response?.ok) {
                setError(response?.error ?? 'Unable to send message');
                return;
            }
            if (response.throttled) {
                setError('You are sending messages too quickly');
                return;
            }
            setDraft('');
            setError(null);
        });
    };
    const panel = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: isDesktop ? '' : 'mx-auto w-full max-w-lg',
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-start justify-between gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-sm font-semibold text-slate-100",
                            children: activeChannel ? CHANNEL_LABELS[activeChannel] : 'Village Chat'
                        }, void 0, false, {
                            fileName: "[project]/components/game/GameChat.tsx",
                            lineNumber: 172,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/game/GameChat.tsx",
                        lineNumber: 171,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            !isDesktop ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "rounded-lg border border-slate-700 bg-slate-900/60 px-2.5 py-1.5 text-[11px] font-semibold text-slate-200 hover:bg-slate-800/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/80",
                                onClick: ()=>setMobileOpen(false),
                                children: "Close"
                            }, void 0, false, {
                                fileName: "[project]/components/game/GameChat.tsx",
                                lineNumber: 178,
                                columnNumber: 13
                            }, this) : null,
                            channels.length > 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex max-w-[10rem] flex-wrap justify-end gap-1",
                                children: channels.map((channel)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: [
                                            'rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] transition-colors',
                                            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/70',
                                            activeChannel === channel ? 'border-amber-400/70 bg-amber-500/15 text-amber-200' : 'border-slate-700 bg-slate-900/60 text-slate-300 hover:border-slate-500'
                                        ].join(' '),
                                        onClick: ()=>{
                                            setActiveChannel(channel);
                                            setError(null);
                                            setUnreadCount(0);
                                            shouldStickToBottomRef.current = true;
                                            setStickToBottom(true);
                                        },
                                        children: CHANNEL_LABELS[channel]
                                    }, channel, false, {
                                        fileName: "[project]/components/game/GameChat.tsx",
                                        lineNumber: 189,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/game/GameChat.tsx",
                                lineNumber: 187,
                                columnNumber: 13
                            }, this) : null
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/game/GameChat.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/GameChat.tsx",
                lineNumber: 170,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: messagePaneRef,
                        className: "lobby-scroll mt-3 h-[min(45svh,18rem)] overflow-y-scroll pr-1 sm:h-44",
                        onScroll: (event)=>{
                            const pane = event.currentTarget;
                            const distanceFromBottom = pane.scrollHeight - pane.scrollTop - pane.clientHeight;
                            const nextStick = distanceFromBottom < 24;
                            shouldStickToBottomRef.current = nextStick;
                            setStickToBottom(nextStick);
                            if (nextStick) setUnreadCount(0);
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex min-h-full flex-col justify-end gap-2",
                            children: activeMessages.length > 0 ? activeMessages.map((message)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                    className: message.userId === 'system' && message.tone === 'death' ? 'w-full rounded-md border border-red-400/70 bg-red-700/30 px-2 py-1.5 shadow-[inset_0_0_0_1px_rgba(239,68,68,0.12)]' : 'border-b border-slate-800/70 pb-1 last:border-b-0',
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-baseline gap-2",
                                        children: [
                                            message.userId !== 'system' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: [
                                                    'shrink-0 text-[11px] font-semibold',
                                                    message.audience === 'dead' ? 'text-slate-500' : message.audience === 'werewolf' ? 'text-red-400' : message.userId === currentUserId ? 'text-sky-300' : 'text-amber-300'
                                                ].join(' '),
                                                children: [
                                                    message.name,
                                                    ":"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/game/GameChat.tsx",
                                                lineNumber: 242,
                                                columnNumber: 23
                                            }, this) : null,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: [
                                                    'min-w-0 flex-1 whitespace-pre-wrap break-words text-xs leading-5',
                                                    message.userId === 'system' ? message.tone === 'death' ? 'font-semibold text-red-50' : 'italic text-slate-400' : 'text-slate-300'
                                                ].join(' '),
                                                children: message.content
                                            }, void 0, false, {
                                                fileName: "[project]/components/game/GameChat.tsx",
                                                lineNumber: 257,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: [
                                                    'shrink-0 text-[10px]',
                                                    message.userId === 'system' && message.tone === 'death' ? 'text-red-100/80' : 'text-slate-500'
                                                ].join(' '),
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatChatTimestamp"])(message.sentAt)
                                            }, void 0, false, {
                                                fileName: "[project]/components/game/GameChat.tsx",
                                                lineNumber: 269,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/game/GameChat.tsx",
                                        lineNumber: 240,
                                        columnNumber: 19
                                    }, this)
                                }, message.id, false, {
                                    fileName: "[project]/components/game/GameChat.tsx",
                                    lineNumber: 232,
                                    columnNumber: 17
                                }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg border border-dashed border-slate-800 bg-slate-900/40 px-3 py-5 text-center text-xs text-slate-500",
                                children: "No messages yet."
                            }, void 0, false, {
                                fileName: "[project]/components/game/GameChat.tsx",
                                lineNumber: 283,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/game/GameChat.tsx",
                            lineNumber: 229,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/game/GameChat.tsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this),
                    !stickToBottom ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: "absolute bottom-2 right-2 inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-950/90 px-3 py-1.5 text-[11px] font-semibold text-slate-100 shadow-lg backdrop-blur transition hover:bg-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/80",
                        onClick: ()=>{
                            const pane = messagePaneRef.current;
                            if (pane) pane.scrollTop = pane.scrollHeight;
                            shouldStickToBottomRef.current = true;
                            setStickToBottom(true);
                            setUnreadCount(0);
                        },
                        children: [
                            "Jump to latest",
                            unreadCount > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "inline-flex min-w-5 items-center justify-center rounded-full bg-amber-400 px-1.5 py-0.5 text-[10px] font-black text-slate-900",
                                children: unreadCount > 99 ? '99+' : unreadCount
                            }, void 0, false, {
                                fileName: "[project]/components/game/GameChat.tsx",
                                lineNumber: 304,
                                columnNumber: 15
                            }, this) : null
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/game/GameChat.tsx",
                        lineNumber: 291,
                        columnNumber: 11
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/GameChat.tsx",
                lineNumber: 215,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                className: "mt-3 space-y-2",
                onSubmit: (event)=>{
                    event.preventDefault();
                    submitMessage();
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: draft,
                        maxLength: 300,
                        rows: 2,
                        className: [
                            'w-full resize-none rounded-lg border px-2.5 py-2 text-xs text-slate-100 outline-none transition-colors placeholder:text-slate-500',
                            activeChannelCanSend ? 'border-slate-800 bg-slate-900/80 focus:border-amber-400/70' : 'cursor-not-allowed border-slate-900 bg-slate-950/80 text-slate-500'
                        ].join(' '),
                        placeholder: `Message ${activeChannel ? CHANNEL_LABELS[activeChannel].toLowerCase() : 'chat'}...`,
                        disabled: !activeChannelCanSend,
                        onChange: (event)=>{
                            setDraft(event.target.value);
                            if (error) setError(null);
                        },
                        onKeyDown: (event)=>{
                            if (event.key === 'Enter' && !event.shiftKey) {
                                event.preventDefault();
                                submitMessage();
                            }
                        }
                    }, void 0, false, {
                        fileName: "[project]/components/game/GameChat.tsx",
                        lineNumber: 319,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "max-w-[11rem] text-[10px] leading-4 text-slate-500",
                                children: helperText
                            }, void 0, false, {
                                fileName: "[project]/components/game/GameChat.tsx",
                                lineNumber: 343,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: !activeChannelCanSend,
                                className: [
                                    'rounded-lg border px-3 py-2 text-xs font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/80',
                                    activeChannelCanSend ? 'border-slate-700 bg-slate-800/80 text-white hover:bg-slate-800' : 'cursor-not-allowed border-slate-900 bg-slate-950 text-slate-500'
                                ].join(' '),
                                children: "Send"
                            }, void 0, false, {
                                fileName: "[project]/components/game/GameChat.tsx",
                                lineNumber: 346,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/game/GameChat.tsx",
                        lineNumber: 342,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/GameChat.tsx",
                lineNumber: 312,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/game/GameChat.tsx",
        lineNumber: 169,
        columnNumber: 5
    }, this);
    return isDesktop ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] left-4 z-40 w-[min(92vw,24rem)] rounded-2xl border border-slate-800 bg-slate-950/92 p-3 text-left shadow-2xl backdrop-blur",
        children: panel
    }, void 0, false, {
        fileName: "[project]/components/game/GameChat.tsx",
        lineNumber: 365,
        columnNumber: 7
    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-end bg-slate-950/70 px-3 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] backdrop-blur-sm",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "w-full rounded-2xl border border-slate-800 bg-slate-950/92 p-3 text-left shadow-2xl",
            children: panel
        }, void 0, false, {
            fileName: "[project]/components/game/GameChat.tsx",
            lineNumber: 370,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/GameChat.tsx",
        lineNumber: 369,
        columnNumber: 7
    }, this);
}
_s(GameChat, "K5Gh8hUcI8EE5CcsKyGyywldUvs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useMediaQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"]
    ];
});
_c = GameChat;
var _c;
__turbopack_context__.k.register(_c, "GameChat");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/constants/storageKeys.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Storage Keys

   Small helpers to keep `localStorage` key naming consistent.
============================================================================= */ __turbopack_context__.s([
    "STORAGE_KEY_PREFIX",
    ()=>STORAGE_KEY_PREFIX,
    "getNotebookStorageKey",
    ()=>getNotebookStorageKey
]);
const STORAGE_KEY_PREFIX = 'werewolf';
const getNotebookStorageKey = (lobbyName, userId)=>`${STORAGE_KEY_PREFIX}:notebook:${lobbyName}:${userId}`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/GameNotebook.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GameNotebook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useMediaQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useMediaQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$uiConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/constants/uiConstants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$storageKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/constants/storageKeys.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function GameNotebook({ lobbyName, userId, canWrite = true, onNotesChange }) {
    _s();
    const isDesktop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useMediaQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$uiConstants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DESKTOP_MEDIA_QUERY"]);
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [notes, setNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [saveState, setSaveState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('idle');
    const lastSentNotesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])('');
    const sendNotesTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const idleTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const storageKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GameNotebook.useMemo[storageKey]": ()=>{
            if (!lobbyName || !userId) return null;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2f$storageKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNotebookStorageKey"])(lobbyName, userId);
        }
    }["GameNotebook.useMemo[storageKey]"], [
        lobbyName,
        userId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameNotebook.useEffect": ()=>{
            if (!storageKey) return;
            if (sendNotesTimeoutRef.current) clearTimeout(sendNotesTimeoutRef.current);
            if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
            sendNotesTimeoutRef.current = null;
            idleTimeoutRef.current = null;
            let initialNotes = '';
            try {
                const existing = window.localStorage.getItem(storageKey);
                initialNotes = existing ?? '';
            } catch  {
                initialNotes = '';
            }
            const id = setTimeout({
                "GameNotebook.useEffect.id": ()=>{
                    setNotes(initialNotes);
                    lastSentNotesRef.current = initialNotes;
                    setSaveState('idle');
                }
            }["GameNotebook.useEffect.id"], 0);
            return ({
                "GameNotebook.useEffect": ()=>clearTimeout(id)
            })["GameNotebook.useEffect"];
        }
    }["GameNotebook.useEffect"], [
        storageKey
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameNotebook.useEffect": ()=>{
            return ({
                "GameNotebook.useEffect": ()=>{
                    if (sendNotesTimeoutRef.current) clearTimeout(sendNotesTimeoutRef.current);
                    if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
                }
            })["GameNotebook.useEffect"];
        }
    }["GameNotebook.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameNotebook.useEffect": ()=>{
            if (!storageKey) return;
            try {
                window.localStorage.setItem(storageKey, notes);
            } catch  {
            // Ignore persistence failures (private mode / storage restrictions)
            }
        }
    }["GameNotebook.useEffect"], [
        storageKey,
        notes
    ]);
    const scheduleSend = (nextNotes)=>{
        if (!canWrite) return;
        if (!onNotesChange) return;
        if (nextNotes === lastSentNotesRef.current) return;
        setSaveState('saving');
        if (sendNotesTimeoutRef.current) clearTimeout(sendNotesTimeoutRef.current);
        if (idleTimeoutRef.current) clearTimeout(idleTimeoutRef.current);
        sendNotesTimeoutRef.current = setTimeout(()=>{
            onNotesChange(nextNotes);
            lastSentNotesRef.current = nextNotes;
            setSaveState('saved');
            idleTimeoutRef.current = setTimeout(()=>{
                setSaveState('idle');
            }, 1200);
        }, 650);
    };
    const statusLabel = !canWrite ? 'Read-only' : saveState === 'saving' ? 'Saving...' : saveState === 'saved' ? 'Saved' : '';
    if (!isDesktop && isOpen) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-end bg-slate-950/70 px-3 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] backdrop-blur-sm",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full rounded-2xl border border-slate-700 bg-slate-900/95 p-4 shadow-2xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-baseline gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "game-section-title",
                                        children: "Notebook"
                                    }, void 0, false, {
                                        fileName: "[project]/components/game/GameNotebook.tsx",
                                        lineNumber: 109,
                                        columnNumber: 15
                                    }, this),
                                    statusLabel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-400",
                                        children: statusLabel
                                    }, void 0, false, {
                                        fileName: "[project]/components/game/GameNotebook.tsx",
                                        lineNumber: 111,
                                        columnNumber: 17
                                    }, this) : null
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/game/GameNotebook.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "rounded-lg border border-slate-700 bg-slate-900/60 px-2.5 py-1.5 text-[11px] font-semibold text-slate-200 hover:bg-slate-800/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/80",
                                onClick: ()=>setIsOpen(false),
                                children: "Close"
                            }, void 0, false, {
                                fileName: "[project]/components/game/GameNotebook.tsx",
                                lineNumber: 116,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/game/GameNotebook.tsx",
                        lineNumber: 107,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: notes,
                        onChange: (e)=>{
                            const nextNotes = e.target.value;
                            setNotes(nextNotes);
                            scheduleSend(nextNotes);
                        },
                        readOnly: !canWrite,
                        placeholder: "Write your notes...",
                        className: [
                            'h-[min(60svh,26rem)] w-full resize-none rounded-xl border border-slate-700 bg-slate-950/70 p-3 text-sm text-slate-100 outline-none',
                            canWrite ? 'focus:ring-2 focus:ring-sky-500' : 'opacity-70'
                        ].join(' ')
                    }, void 0, false, {
                        fileName: "[project]/components/game/GameNotebook.tsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this),
                    !canWrite && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-xs text-slate-400",
                        children: "You have been eliminated. Notebook is read-only."
                    }, void 0, false, {
                        fileName: "[project]/components/game/GameNotebook.tsx",
                        lineNumber: 139,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/GameNotebook.tsx",
                lineNumber: 106,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/game/GameNotebook.tsx",
            lineNumber: 105,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: [
            'fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] right-4 z-40',
            isOpen ? 'w-[min(92vw,24rem)]' : 'w-auto'
        ].join(' '),
        children: isOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "rounded-2xl border border-slate-700 bg-slate-900/95 p-4 shadow-2xl backdrop-blur",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-baseline gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "game-section-title",
                                    children: "Notebook"
                                }, void 0, false, {
                                    fileName: "[project]/components/game/GameNotebook.tsx",
                                    lineNumber: 159,
                                    columnNumber: 15
                                }, this),
                                statusLabel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-400",
                                    children: statusLabel
                                }, void 0, false, {
                                    fileName: "[project]/components/game/GameNotebook.tsx",
                                    lineNumber: 161,
                                    columnNumber: 17
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/game/GameNotebook.tsx",
                            lineNumber: 158,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "text-xs text-slate-300 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/80 rounded-md",
                            onClick: ()=>setIsOpen(false),
                            children: "Close"
                        }, void 0, false, {
                            fileName: "[project]/components/game/GameNotebook.tsx",
                            lineNumber: 166,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/game/GameNotebook.tsx",
                    lineNumber: 157,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    value: notes,
                    onChange: (e)=>{
                        const nextNotes = e.target.value;
                        setNotes(nextNotes);
                        scheduleSend(nextNotes);
                    },
                    readOnly: !canWrite,
                    placeholder: "Write your notes...",
                    className: [
                        'min-h-52 w-full resize-y rounded-xl border border-slate-700 bg-slate-950/70 p-3 text-sm text-slate-100 outline-none',
                        canWrite ? 'focus:ring-2 focus:ring-sky-500' : 'opacity-70'
                    ].join(' ')
                }, void 0, false, {
                    fileName: "[project]/components/game/GameNotebook.tsx",
                    lineNumber: 174,
                    columnNumber: 11
                }, this),
                !canWrite && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-2 text-xs text-slate-400",
                    children: "You have been eliminated. Notebook is read-only."
                }, void 0, false, {
                    fileName: "[project]/components/game/GameNotebook.tsx",
                    lineNumber: 189,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/game/GameNotebook.tsx",
            lineNumber: 156,
            columnNumber: 9
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            "aria-label": "Open notebook",
            title: "Open notebook",
            className: "inline-flex h-12 w-12 items-center justify-center rounded-full border border-slate-700 bg-slate-900/95 text-slate-100 shadow-2xl transition hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/80",
            onClick: ()=>setIsOpen(true),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-lg leading-none",
                "aria-hidden": "true",
                children: '\u270E'
            }, void 0, false, {
                fileName: "[project]/components/game/GameNotebook.tsx",
                lineNumber: 202,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/game/GameNotebook.tsx",
            lineNumber: 195,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/GameNotebook.tsx",
        lineNumber: 149,
        columnNumber: 5
    }, this);
}
_s(GameNotebook, "I3vGD2Heg6NYekBEkm8fVwH9QHk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useMediaQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"]
    ];
});
_c = GameNotebook;
var _c;
__turbopack_context__.k.register(_c, "GameNotebook");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/NotebookModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotebookModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function NotebookModal({ notebook, onClose }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 px-3 sm:px-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-2xl rounded-2xl border border-slate-700 bg-slate-900 p-5 shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3 flex items-start justify-between gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-slate-100 font-semibold",
                            children: [
                                notebook.name,
                                "'s Notebook"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/game/NotebookModal.tsx",
                            lineNumber: 13,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "inline-flex h-8 w-8 items-center justify-center rounded-full border border-slate-600 text-slate-200 hover:bg-slate-800",
                            "aria-label": "Close notebook",
                            onClick: onClose,
                            children: "X"
                        }, void 0, false, {
                            fileName: "[project]/components/game/NotebookModal.tsx",
                            lineNumber: 16,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/game/NotebookModal.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-lg border border-slate-700 bg-slate-950/80 p-4 text-sm text-slate-200 whitespace-pre-wrap max-h-[70svh] overflow-y-auto",
                    children: notebook.content.trim() || 'No notes were found.'
                }, void 0, false, {
                    fileName: "[project]/components/game/NotebookModal.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/game/NotebookModal.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/NotebookModal.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_c = NotebookModal;
var _c;
__turbopack_context__.k.register(_c, "NotebookModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/GameFloatingPanels.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GameFloatingPanels
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameChat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/GameChat.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameNotebook$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/GameNotebook.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$NotebookModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/NotebookModal.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
function GameFloatingPanels({ currentPhase, lobbyName, currentUserId, chatRefreshKey, canWriteNotebook, onNotesChange, viewingNotebook, onCloseNotebook }) {
    const showChat = currentPhase !== 'nightResults' && currentPhase !== 'endGame' && currentPhase !== 'gameResults';
    const showNotebook = currentPhase !== 'roleReveal' && currentPhase !== 'endGame' && currentPhase !== 'gameResults';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            showChat ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameChat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                lobbyName: lobbyName,
                refreshKey: chatRefreshKey,
                currentUserId: currentUserId
            }, void 0, false, {
                fileName: "[project]/components/game/GameFloatingPanels.tsx",
                lineNumber: 49,
                columnNumber: 9
            }, this) : null,
            showNotebook ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameNotebook$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                lobbyName: lobbyName,
                userId: currentUserId,
                canWrite: canWriteNotebook,
                onNotesChange: onNotesChange
            }, void 0, false, {
                fileName: "[project]/components/game/GameFloatingPanels.tsx",
                lineNumber: 57,
                columnNumber: 9
            }, this) : null,
            viewingNotebook ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$NotebookModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                notebook: viewingNotebook,
                onClose: onCloseNotebook
            }, void 0, false, {
                fileName: "[project]/components/game/GameFloatingPanels.tsx",
                lineNumber: 66,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true);
}
_c = GameFloatingPanels;
var _c;
__turbopack_context__.k.register(_c, "GameFloatingPanels");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/GameOverlays.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GameOverlays
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function GameOverlays({ phaseOverlayState, showResultsFadeOut }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: [
                    'game-phase-overlay z-40',
                    phaseOverlayState.mode === 'fadeIn' ? 'phase-overlay-fade-in' : phaseOverlayState.mode === 'fadeOut' ? 'phase-overlay-fade-out' : 'opacity-0'
                ].join(' ')
            }, phaseOverlayState.key, false, {
                fileName: "[project]/components/game/GameOverlays.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            showResultsFadeOut ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "game-phase-overlay z-50 phase-overlay-fade-out"
            }, "results-route-fadeout", false, {
                fileName: "[project]/components/game/GameOverlays.tsx",
                lineNumber: 38,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true);
}
_c = GameOverlays;
var _c;
__turbopack_context__.k.register(_c, "GameOverlays");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/GameStartingScene.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GameStartingScene
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
function GameStartingScene({ startingRemainingSeconds }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "game-cinematic-scene min-h-[100svh] flex items-center justify-center px-4 sm:px-6 py-10 sm:py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-3xl text-center space-y-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "game-tight-label",
                    children: "Starting"
                }, void 0, false, {
                    fileName: "[project]/components/game/GameStartingScene.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "game-title",
                    children: "Game begins soon"
                }, void 0, false, {
                    fileName: "[project]/components/game/GameStartingScene.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-slate-300 text-sm",
                    children: startingRemainingSeconds !== null ? `Starting in ${startingRemainingSeconds}s...` : 'Preparing the lobby...'
                }, void 0, false, {
                    fileName: "[project]/components/game/GameStartingScene.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/game/GameStartingScene.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/GameStartingScene.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_c = GameStartingScene;
var _c;
__turbopack_context__.k.register(_c, "GameStartingScene");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/MemberActionRow.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MemberActionRow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/actions/gameSocketActions.ts [app-client] (ecmascript)");
;
;
const getNightActionForRole = (roleName)=>{
    switch(roleName){
        case 'Werewolf':
        case 'AlphaWolf':
        case 'Hunter':
            return {
                kind: 'nightKill',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nightKill"]
            };
        case 'Escort':
            return {
                kind: 'escortVisit',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escortVisit"]
            };
        case 'Bodyguard':
            return {
                kind: 'bodyguardGuard',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bodyguardGuard"]
            };
        case 'Doctor':
            return {
                kind: 'doctorProtect',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doctorProtect"]
            };
        case 'Tracker':
            return {
                kind: 'trackerWatch',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackerWatch"]
            };
        case 'Lookout':
            return {
                kind: 'lookoutWatch',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lookoutWatch"]
            };
        case 'Investigator':
            return {
                kind: 'investigate',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["investigate"]
            };
        case 'Framer':
            return {
                kind: 'frame',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["frame"]
            };
        case 'Prowler':
            return {
                kind: 'prowl',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prowl"]
            };
        case 'Snatcher':
            return {
                kind: 'snatch',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["snatch"]
            };
        case 'Cursed':
            return {
                kind: 'curse',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["curse"]
            };
        case 'Mimic':
            return {
                kind: 'mimic',
                dispatch: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mimic"]
            };
        default:
            return null;
    }
};
const canTargetSelfForNightAction = (nightAction)=>nightAction.kind === 'lookoutWatch' || nightAction.kind === 'doctorProtect' || nightAction.kind === 'frame' || nightAction.kind === 'curse';
function MemberActionRow({ lobbyName, member, currentPhase, effectiveDisplayPhase, roleName, selfAlive, currentUserId, werewolfUserIds, hunterShotsRemaining, doctorSelfProtectUsed, executionerTargetUserId, selectedNightActionTargetId, setSelectedNightActionTargetId, selectedVoteTargetId, setSelectedVoteTargetId, setViewingNotebook }) {
    const isNightActionOpen = currentPhase === 'night';
    const nightAction = getNightActionForRole(roleName);
    const needsNightTarget = isNightActionOpen && selfAlive && member.alive && nightAction !== null;
    const disallowSelfTarget = currentUserId && member.userId === currentUserId && nightAction !== null && !canTargetSelfForNightAction(nightAction);
    const disallowHunterNoShots = roleName === 'Hunter' && hunterShotsRemaining <= 0;
    const disallowDoctorSelfProtect = roleName === 'Doctor' && currentUserId && member.userId === currentUserId && doctorSelfProtectUsed;
    const canDoNightAction = needsNightTarget && !disallowSelfTarget && !disallowHunterNoShots && !disallowDoctorSelfProtect;
    const canViewDeadNotebook = (effectiveDisplayPhase === 'day' || effectiveDisplayPhase === 'night') && !member.alive;
    const canVoteNow = currentPhase === 'vote' && selfAlive && member.alive;
    const isActionable = canDoNightAction && nightAction !== null || canViewDeadNotebook || canVoteNow;
    const isSelectedTarget = canDoNightAction && selectedNightActionTargetId === member.userId || canVoteNow && selectedVoteTargetId === member.userId;
    const isExecutionerTarget = roleName === 'Executioner' && executionerTargetUserId === member.userId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        disabled: !isActionable || !lobbyName,
        "aria-pressed": isSelectedTarget,
        "aria-label": isActionable ? `${member.name} is selectable` : `${member.name} is not selectable right now`,
        className: [
            'game-box relative w-full text-left transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/80',
            isActionable ? 'cursor-pointer border-sky-500/50 bg-sky-500/10 hover:bg-sky-500/20 hover:border-sky-400/70 hover:translate-y-[-1px]' : 'opacity-50 cursor-not-allowed border-slate-700/50 bg-slate-900/40',
            isSelectedTarget ? 'border-amber-300/90 bg-gradient-to-r from-amber-500/16 to-sky-500/8 ring-4 ring-amber-400/35 shadow-[0_0_0_1px_rgba(251,191,36,0.55),0_0_24px_rgba(251,191,36,0.14)] translate-y-0 hover:translate-y-0' : ''
        ].join(' '),
        onClick: ()=>{
            if (!lobbyName) return;
            if (canDoNightAction && nightAction) {
                setSelectedNightActionTargetId((previous)=>previous === member.userId ? null : member.userId);
                nightAction.dispatch(lobbyName, member.userId);
                return;
            }
            if (canViewDeadNotebook) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNotebook"])(lobbyName, member.userId, (response)=>{
                    if (!response?.ok || !response.notebook) return;
                    setViewingNotebook({
                        name: response.notebook.name,
                        content: response.notebook.content ?? ''
                    });
                });
                return;
            }
            if (canVoteNow) {
                setSelectedVoteTargetId((previous)=>previous === member.userId ? null : member.userId);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castVote"])(lobbyName, member.userId);
            }
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-center gap-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: [
                        'font-semibold',
                        werewolfUserIds.includes(member.userId) ? 'text-red-300' : isExecutionerTarget ? 'text-violet-300' : 'text-white'
                    ].join(' '),
                    children: member.name
                }, void 0, false, {
                    fileName: "[project]/components/game/MemberActionRow.tsx",
                    lineNumber: 204,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/game/MemberActionRow.tsx",
                lineNumber: 203,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-center gap-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: [
                        'inline-flex items-center justify-center h-7 w-7 rounded-full border',
                        member.alive ? 'text-emerald-200 border-emerald-500/40 bg-emerald-500/10' : 'text-red-200 border-red-500/40 bg-red-500/10'
                    ].join(' '),
                    role: "img",
                    "aria-label": member.alive ? 'Alive' : 'Dead',
                    title: member.alive ? 'Alive' : 'Dead',
                    children: member.alive ? '\u25CF' : '\u2620'
                }, void 0, false, {
                    fileName: "[project]/components/game/MemberActionRow.tsx",
                    lineNumber: 218,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/game/MemberActionRow.tsx",
                lineNumber: 217,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/game/MemberActionRow.tsx",
        lineNumber: 155,
        columnNumber: 5
    }, this);
}
_c = MemberActionRow;
var _c;
__turbopack_context__.k.register(_c, "MemberActionRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/NightResultsScene.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NightResultsScene
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function NightResultsScene({ revealState, revealDeath, endGameButton }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "game-cinematic-scene min-h-[100svh] px-4 sm:px-6 py-10 sm:py-12 flex items-center justify-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: [
                'w-full max-w-3xl space-y-6 text-center transition-opacity duration-700',
                revealState === 'fading' ? 'opacity-0' : 'opacity-100'
            ].join(' '),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: [
                        'reveal-prefix transition-all duration-700',
                        revealState === 'heading' || revealState === 'line1' || revealState === 'line2' || revealState === 'notebook' || revealState === 'fading' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
                    ].join(' '),
                    children: "Who Died and How?"
                }, void 0, false, {
                    fileName: "[project]/components/game/NightResultsScene.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: [
                        'text-4xl md:text-5xl font-black uppercase tracking-[0.04em] transition-all duration-700',
                        revealDeath ? 'text-red-300' : 'text-emerald-300',
                        revealState === 'line1' || revealState === 'line2' || revealState === 'notebook' || revealState === 'fading' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                    ].join(' '),
                    children: revealDeath ? `${revealDeath.name} died last night.` : 'No one died last night.'
                }, void 0, false, {
                    fileName: "[project]/components/game/NightResultsScene.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: [
                        'reveal-subtitle transition-all duration-700',
                        revealState === 'line2' || revealState === 'notebook' || revealState === 'fading' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
                    ].join(' '),
                    children: revealDeath ? 'They were slain under cover of darkness.' : 'Dawn breaks in uneasy silence.'
                }, void 0, false, {
                    fileName: "[project]/components/game/NightResultsScene.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, this),
                revealDeath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: [
                        'mx-auto w-full max-w-2xl rounded-lg border border-slate-700 bg-slate-950/80 p-3 text-left text-sm text-slate-200 whitespace-pre-wrap transition-all duration-700',
                        revealState === 'notebook' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'
                    ].join(' '),
                    children: revealDeath.notebook.trim() || 'No final notes were left behind.'
                }, void 0, false, {
                    fileName: "[project]/components/game/NightResultsScene.tsx",
                    lineNumber: 67,
                    columnNumber: 11
                }, this) : null,
                endGameButton ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pt-6 max-w-xs mx-auto",
                    children: endGameButton
                }, void 0, false, {
                    fileName: "[project]/components/game/NightResultsScene.tsx",
                    lineNumber: 78,
                    columnNumber: 26
                }, this) : null
            ]
        }, void 0, true, {
            fileName: "[project]/components/game/NightResultsScene.tsx",
            lineNumber: 18,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/NightResultsScene.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_c = NightResultsScene;
var _c;
__turbopack_context__.k.register(_c, "NightResultsScene");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/useNowTicker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useNowTicker",
    ()=>useNowTicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useNowTicker(enabled, intervalMs = 250) {
    _s();
    const [nowMs, setNowMs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useNowTicker.useEffect": ()=>{
            if (!enabled) {
                const resetId = setTimeout({
                    "useNowTicker.useEffect.resetId": ()=>{
                        setNowMs(null);
                    }
                }["useNowTicker.useEffect.resetId"], 0);
                return ({
                    "useNowTicker.useEffect": ()=>clearTimeout(resetId)
                })["useNowTicker.useEffect"];
            }
            const kickoffId = setTimeout({
                "useNowTicker.useEffect.kickoffId": ()=>{
                    setNowMs(Date.now());
                }
            }["useNowTicker.useEffect.kickoffId"], 0);
            const id = setInterval({
                "useNowTicker.useEffect.id": ()=>{
                    setNowMs(Date.now());
                }
            }["useNowTicker.useEffect.id"], intervalMs);
            return ({
                "useNowTicker.useEffect": ()=>{
                    clearTimeout(kickoffId);
                    clearInterval(id);
                }
            })["useNowTicker.useEffect"];
        }
    }["useNowTicker.useEffect"], [
        enabled,
        intervalMs
    ]);
    return nowMs;
}
_s(useNowTicker, "BXeI7xx2+8P3yftLpVRBBep4Ntg=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/PhaseTimer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PhaseTimer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useNowTicker.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/formatters/timeFormatters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
function PhaseTimerBar({ phaseEndsAt, phaseDurationMs, barClassName }) {
    _s();
    const fillRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PhaseTimerBar.useEffect": ()=>{
            const fill = fillRef.current;
            if (!fill) return;
            const now = Date.now();
            const startAt = phaseEndsAt - phaseDurationMs;
            const elapsedMs = Math.min(phaseDurationMs, Math.max(0, now - startAt));
            // Restart the CSS animation at the correct progress point.
            fill.style.animation = 'none';
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            fill.offsetHeight;
            fill.style.animation = '';
            fill.style.animationDuration = `${phaseDurationMs}ms`;
            fill.style.animationDelay = `-${elapsedMs}ms`;
        }
    }["PhaseTimerBar.useEffect"], [
        phaseDurationMs,
        phaseEndsAt
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-1.5 w-full overflow-hidden rounded-full bg-white/10",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: fillRef,
            className: [
                'h-full w-full rounded-full phase-timer-bar-fill',
                barClassName
            ].join(' ')
        }, void 0, false, {
            fileName: "[project]/components/game/PhaseTimer.tsx",
            lineNumber: 42,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/PhaseTimer.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_s(PhaseTimerBar, "/bCvsHLZppcYn+l67o1widLIpC4=");
_c = PhaseTimerBar;
function PhaseTimer({ phaseEndsAt, phaseDurationMs }) {
    _s1();
    const nowMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNowTicker"])(!!phaseEndsAt, 250);
    const isReady = phaseEndsAt !== null && nowMs !== null;
    const remainingSeconds = isReady ? Math.max(0, Math.floor((phaseEndsAt - nowMs) / 1000)) : 0;
    const remaining = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatMinutesSeconds"])(remainingSeconds);
    const { intentClassName, barClassName, showPulse } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PhaseTimer.useMemo": ()=>{
            const seconds = remainingSeconds;
            const intent = seconds <= 15 ? 'danger' : 'normal';
            const intentClassName = intent === 'danger' ? 'border-red-400/50 bg-red-500/10 text-red-200' : 'border-sky-500/40 bg-sky-500/10 text-sky-200';
            const barClassName = intent === 'danger' ? 'bg-red-400' : 'bg-sky-400';
            return {
                intentClassName,
                barClassName,
                showPulse: seconds <= 10
            };
        }
    }["PhaseTimer.useMemo"], [
        remainingSeconds
    ]);
    if (!isReady) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "timer",
        "aria-live": "off",
        "aria-label": `Phase ends in ${remaining}`,
        className: [
            'inline-flex flex-col gap-2 rounded-2xl border px-4 py-2 text-xs font-semibold uppercase tracking-[0.15em]',
            intentClassName,
            showPulse ? 'phase-timer-pulse' : ''
        ].join(' '),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "inline-flex items-center justify-between gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Phase ends in"
                    }, void 0, false, {
                        fileName: "[project]/components/game/PhaseTimer.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "tabular-nums",
                        children: remaining
                    }, void 0, false, {
                        fileName: "[project]/components/game/PhaseTimer.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/PhaseTimer.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this),
            phaseDurationMs && phaseDurationMs > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PhaseTimerBar, {
                phaseEndsAt: phaseEndsAt,
                phaseDurationMs: phaseDurationMs,
                barClassName: barClassName
            }, Math.floor(phaseEndsAt / 1000), false, {
                fileName: "[project]/components/game/PhaseTimer.tsx",
                lineNumber: 99,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/components/game/PhaseTimer.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_s1(PhaseTimer, "cZc34f70pFXTHHTi+UqQPT5onWw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNowTicker"]
    ];
});
_c1 = PhaseTimer;
var _c, _c1;
__turbopack_context__.k.register(_c, "PhaseTimerBar");
__turbopack_context__.k.register(_c1, "PhaseTimer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/PlayerList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PlayerList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function PlayerList({ members, renderMemberRow }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3 pt-2",
        children: members.length ? members.map((member)=>renderMemberRow(member)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "game-box",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-slate-300 text-sm",
                children: "No players found."
            }, void 0, false, {
                fileName: "[project]/components/game/PlayerList.tsx",
                lineNumber: 16,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/game/PlayerList.tsx",
            lineNumber: 15,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/PlayerList.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = PlayerList;
var _c;
__turbopack_context__.k.register(_c, "PlayerList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shared/InfoPopover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InfoPopover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
function InfoPopover({ ariaLabel, align = 'right', widthClassName = 'w-64', children }) {
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InfoPopover.useEffect": ()=>{
            if (!open) return;
            const onPointerDown = {
                "InfoPopover.useEffect.onPointerDown": (event)=>{
                    const container = containerRef.current;
                    if (!container) return;
                    if (event.target instanceof Node && container.contains(event.target)) return;
                    setOpen(false);
                }
            }["InfoPopover.useEffect.onPointerDown"];
            document.addEventListener('pointerdown', onPointerDown, true);
            return ({
                "InfoPopover.useEffect": ()=>{
                    document.removeEventListener('pointerdown', onPointerDown, true);
                }
            })["InfoPopover.useEffect"];
        }
    }["InfoPopover.useEffect"], [
        open
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        className: "relative inline-flex items-center z-40",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                "aria-label": ariaLabel,
                "aria-expanded": open,
                className: "inline-flex h-5 w-5 items-center justify-center rounded-full border border-slate-500/60 text-[11px] font-bold text-slate-200 hover:bg-slate-700/60 focus:outline-none focus:ring-2 focus:ring-sky-400",
                onKeyDown: (e)=>{
                    if (e.key === 'Escape') setOpen(false);
                },
                onClick: ()=>setOpen((prev)=>!prev),
                children: "i"
            }, void 0, false, {
                fileName: "[project]/components/shared/InfoPopover.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: [
                    'absolute top-full z-[999] mt-2 max-w-[calc(100vw-1rem)] rounded-md border border-slate-600 bg-slate-900/95 p-2 text-left text-xs text-slate-200 shadow-lg transition-opacity',
                    widthClassName,
                    align === 'left' ? 'left-1/2 -translate-x-1/2 sm:left-auto sm:translate-x-0 sm:right-0' : 'right-0',
                    open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
                ].join(' '),
                children: children
            }, void 0, false, {
                fileName: "[project]/components/shared/InfoPopover.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/shared/InfoPopover.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(InfoPopover, "c70JY9p7Da/HTz1NuXGWiUA9JHk=");
_c = InfoPopover;
var _c;
__turbopack_context__.k.register(_c, "InfoPopover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/RoleInfoPopover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RoleInfoPopover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/shared/InfoPopover.tsx [app-client] (ecmascript)");
;
;
function RoleInfoPopover({ roleDisplayName, roleName, roleInfo, hunterShotsRemaining, trapperAlertsRemaining, executionerTargetName, executionerTargetUserId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        ariaLabel: `${roleDisplayName} role info`,
        align: "right",
        widthClassName: "w-72",
        children: [
            roleInfo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "leading-tight",
                        children: roleInfo.ability
                    }, void 0, false, {
                        fileName: "[project]/components/game/RoleInfoPopover.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1 leading-tight text-amber-300",
                        children: [
                            "Win: ",
                            roleInfo.winCondition
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/game/RoleInfoPopover.tsx",
                        lineNumber: 35,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "leading-tight text-slate-300",
                children: "Role information unavailable."
            }, void 0, false, {
                fileName: "[project]/components/game/RoleInfoPopover.tsx",
                lineNumber: 40,
                columnNumber: 9
            }, this),
            roleName === 'Hunter' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 leading-tight text-sky-300",
                children: [
                    "Shots remaining: ",
                    hunterShotsRemaining
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/RoleInfoPopover.tsx",
                lineNumber: 45,
                columnNumber: 9
            }, this) : null,
            roleName === 'Trapper' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 leading-tight text-sky-300",
                children: [
                    "Alerts remaining: ",
                    trapperAlertsRemaining
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/RoleInfoPopover.tsx",
                lineNumber: 50,
                columnNumber: 9
            }, this) : null,
            roleName === 'Executioner' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-1 leading-tight text-violet-300",
                children: [
                    "Target: ",
                    executionerTargetName ?? executionerTargetUserId ?? 'None'
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/RoleInfoPopover.tsx",
                lineNumber: 55,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/components/game/RoleInfoPopover.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c = RoleInfoPopover;
var _c;
__turbopack_context__.k.register(_c, "RoleInfoPopover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/PlayerRoleCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PlayerRoleCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$RoleInfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/RoleInfoPopover.tsx [app-client] (ecmascript)");
'use client';
;
;
function PlayerRoleCard({ roleName, roleDisplayName, roleInfo, hunterShotsRemaining, trapperAlertsRemaining, executionerTargetName, executionerTargetUserId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: [
            'game-box w-full sm:w-auto shrink-0 text-left sm:min-w-[13rem]',
            // Keep the role readable without making the header feel tall.
            'flex-col items-start justify-start gap-1.5 px-5 py-3'
        ].join(' '),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full flex items-center justify-between gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "game-tight-label",
                        children: "Your role"
                    }, void 0, false, {
                        fileName: "[project]/components/game/PlayerRoleCard.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$RoleInfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        roleDisplayName: roleDisplayName,
                        roleName: roleName,
                        roleInfo: roleInfo,
                        hunterShotsRemaining: hunterShotsRemaining,
                        trapperAlertsRemaining: trapperAlertsRemaining,
                        executionerTargetName: executionerTargetName,
                        executionerTargetUserId: executionerTargetUserId
                    }, void 0, false, {
                        fileName: "[project]/components/game/PlayerRoleCard.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/game/PlayerRoleCard.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "w-full font-bold text-slate-100 text-base sm:text-lg leading-tight break-words",
                children: roleDisplayName
            }, void 0, false, {
                fileName: "[project]/components/game/PlayerRoleCard.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/game/PlayerRoleCard.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_c = PlayerRoleCard;
var _c;
__turbopack_context__.k.register(_c, "PlayerRoleCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/models/roles.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ROLES",
    ()=>ROLES,
    "ROLE_NAMES",
    ()=>ROLE_NAMES,
    "VILLAGE_ROLES_BY_CATEGORY",
    ()=>VILLAGE_ROLES_BY_CATEGORY,
    "VILLAGE_ROLE_NAMES",
    ()=>VILLAGE_ROLE_NAMES,
    "getRoleDisplayName",
    ()=>getRoleDisplayName
]);
const getRoleDisplayName = (roleName)=>{
    if (roleName === 'AlphaWolf') return 'Alpha Wolf';
    return roleName;
};
const ROLES = {
    Villager: {
        faction: 'Village',
        category: 'Basic',
        ability: 'No special ability.',
        nightInstruction: 'You have no night action. Discuss and vote during the day.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'A steady voice in the dark. Read the room, sway the vote, and expose the pack.'
    },
    Werewolf: {
        faction: 'Enemy',
        category: 'Killing',
        ability: 'Coordinate at night and choose a player to eliminate.',
        nightInstruction: 'Choose a player to kill. Coordinate with other werewolves in secret chat.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Hide behind a friendly face by day, then hunt as one beneath the moon.'
    },
    AlphaWolf: {
        faction: 'Enemy',
        category: 'Killing',
        ability: "Choose the werewolves' kill target each night.",
        nightInstruction: "Choose the werewolves' kill target tonight. Coordinate with other werewolves in secret chat.",
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'You lead the hunt. Every night, your choice shapes who sees dawn.'
    },
    Framer: {
        faction: 'Enemy',
        category: 'Information',
        ability: 'Frame one player at night. Investigative results on them may appear suspicious.',
        nightInstruction: 'Choose a player to frame. Some investigative results on them may appear suspicious tonight.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Plant false clues and turn honest eyes toward the innocent.'
    },
    Prowler: {
        faction: 'Enemy',
        category: 'Information',
        ability: 'Prowl one player at night for clues on their role.',
        nightInstruction: 'Choose a player to prowl. You will receive a list of possible roles.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Quiet reconnaissance wins wars before the claws come out.'
    },
    Snatcher: {
        faction: 'Enemy',
        category: 'Control',
        ability: 'Snatch one player at night to roleblock them.',
        nightInstruction: 'Choose a player to snatch. Their night action (if any) will fail.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Drag key players off the board and watch plans unravel.'
    },
    Cursed: {
        faction: 'Enemy',
        category: 'Control',
        ability: 'Curse one player at night. Cursed players cannot be protected by a Doctor that night.',
        nightInstruction: 'Choose a player to curse. If a Doctor protects them tonight, the protection fails.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'A whisper of ruin that turns safety into false hope.'
    },
    Mimic: {
        faction: 'Enemy',
        category: 'Information',
        ability: 'Choose a player at night to mimic their role in village investigative checks.',
        nightInstruction: 'Choose a player to mimic. Village investigative checks may see you as their role.',
        winCondition: 'Enemy team wins when werewolves reach parity with Village.',
        revealSummary: 'Borrow a mask for the night and let suspicion land elsewhere.'
    },
    Doctor: {
        faction: 'Village',
        category: 'Support',
        ability: 'Choose a player at night to protect from a kill. You may protect yourself once per game.',
        nightInstruction: 'Choose a player to protect from a kill tonight. You may protect yourself once per game.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Keep hearts beating through the longest nights. Your protection can change everything.'
    },
    Tracker: {
        faction: 'Village',
        category: 'Information',
        ability: 'Choose a player at night to learn who they visited.',
        nightInstruction: 'Choose a player to track. You will learn who they visited.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Follow footprints in the dark and uncover who moves when no one should.'
    },
    Lookout: {
        faction: 'Village',
        category: 'Information',
        ability: 'Choose a player at night to see who visited them.',
        nightInstruction: 'Choose a player to watch. You will learn who visited them.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Watch the doors no one else watches. Witnesses decide who survives dawn.'
    },
    Investigator: {
        faction: 'Village',
        category: 'Information',
        ability: 'Investigate one player at night for clues on their role.',
        nightInstruction: 'Choose a player to investigate. You will receive a list of possible roles.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Piece together subtle tells and quiet lies to reveal the truth beneath the masks.'
    },
    Hunter: {
        faction: 'Village',
        category: 'Killing',
        ability: 'At night, choose a player to shoot (up to 3 shots total). If you kill a Village role, you die from guilt.',
        nightInstruction: ({ hunterShotsRemaining })=>(hunterShotsRemaining ?? 0) > 0 ? `Choose a player to shoot. Shots remaining: ${hunterShotsRemaining ?? 0}.` : 'You have no shots remaining tonight.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Justice rides with your rifle. Every shot matters, and every mistake has a price.'
    },
    Trapper: {
        faction: 'Village',
        category: 'Control',
        ability: 'At night, you may activate alert (up to 3 uses). Attackers who target you during alert are killed.',
        nightInstruction: ({ trapperAlertsRemaining, trapperAlertActive })=>trapperAlertActive ? 'Alert is active tonight.' : (trapperAlertsRemaining ?? 0) > 0 ? `Use "Activate Alert" to set a trap on yourself tonight. Alerts remaining: ${trapperAlertsRemaining ?? 0}.` : 'You have no alerts remaining tonight.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Set yourself as bait and spring the trap. Predators who strike carelessly may not return.'
    },
    Escort: {
        faction: 'Village',
        category: 'Control',
        ability: 'Roleblock one player at night so their action fails.',
        nightInstruction: 'Choose a player to roleblock so their night action fails.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Keep dangerous players occupied and throw enemy plans into disarray.'
    },
    Bodyguard: {
        faction: 'Village',
        category: 'Support',
        ability: 'Guard a player and intercept a hostile attack.',
        nightInstruction: 'Choose a player to guard. You will intercept a hostile attack aimed at them.',
        winCondition: 'Village wins when all werewolves are eliminated.',
        revealSummary: 'Stand between claw and kin. Your watch may be the wall that holds the village together.'
    },
    Jester: {
        faction: 'Neutral',
        category: 'Objective',
        ability: 'Cause chaos and attract suspicion.',
        nightInstruction: 'You have no night action. Try to get yourself executed during the day.',
        winCondition: 'Win by being executed by daytime vote.',
        revealSummary: 'Twist the town against you until they hand you victory at the gallows.'
    },
    Executioner: {
        faction: 'Neutral',
        category: 'Objective',
        ability: 'Has a specific target to push for execution. If that target dies at night, you become a Jester.',
        nightInstruction: 'You have no night action. Push your target during the day vote.',
        winCondition: 'Win if your assigned target is executed by vote.',
        revealSummary: 'Guide one chosen soul toward the noose; if fate steals them first, embrace chaos as Jester.'
    }
};
const ROLE_NAMES = Object.keys(ROLES);
_c = ROLE_NAMES;
const VILLAGE_ROLE_NAMES = ROLE_NAMES.filter(_c1 = (role)=>ROLES[role].faction === 'Village');
_c2 = VILLAGE_ROLE_NAMES;
const VILLAGE_ROLES_BY_CATEGORY = {
    Basic: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Basic'),
    Killing: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Killing'),
    Support: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Support'),
    Information: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Information'),
    Control: VILLAGE_ROLE_NAMES.filter((role)=>ROLES[role].category === 'Control')
};
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ROLE_NAMES");
__turbopack_context__.k.register(_c1, "VILLAGE_ROLE_NAMES$ROLE_NAMES.filter");
__turbopack_context__.k.register(_c2, "VILLAGE_ROLE_NAMES");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/game/RoleRevealScene.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RoleRevealScene
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/models/roles.ts [app-client] (ecmascript)");
;
;
function RoleRevealScene({ phaseEndsAt, revealState, roleName, roleToneClass, endGameButton }) {
    const roleDisplayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRoleDisplayName"])(roleName);
    const roleRevealSummary = roleName in __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"] ? __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"][roleName].revealSummary : 'Hold your nerve. Dawn reveals all truths.';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "game-cinematic-scene min-h-[100svh] flex items-center justify-center px-4 sm:px-6 py-10 sm:py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-3xl text-center",
            children: [
                revealState !== 'hidden' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: [
                        'space-y-7 transition-all duration-700 ease-in-out',
                        'will-change-[opacity,transform]',
                        revealState === 'fading' ? 'opacity-0 -translate-y-2' : 'opacity-100 translate-y-0'
                    ].join(' '),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: [
                                'reveal-prefix transition-opacity duration-700 ease-in-out',
                                revealState === 'titlePre' ? 'opacity-0' : 'opacity-100'
                            ].join(' '),
                            children: "Your Role"
                        }, void 0, false, {
                            fileName: "[project]/components/game/RoleRevealScene.tsx",
                            lineNumber: 48,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: [
                                'reveal-role transition-opacity duration-700 ease-in-out',
                                revealState === 'role' || revealState === 'fading' ? `${roleToneClass} opacity-100` : 'reveal-role-placeholder opacity-0'
                            ].join(' '),
                            children: roleDisplayName
                        }, void 0, false, {
                            fileName: "[project]/components/game/RoleRevealScene.tsx",
                            lineNumber: 56,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: [
                                'reveal-subtitle transition-opacity duration-700 ease-in-out',
                                revealState === 'role' || revealState === 'fading' ? 'opacity-100' : 'opacity-0'
                            ].join(' '),
                            children: revealState === 'role' || revealState === 'rolePre' || revealState === 'fading' ? roleRevealSummary : ' '
                        }, void 0, false, {
                            fileName: "[project]/components/game/RoleRevealScene.tsx",
                            lineNumber: 66,
                            columnNumber: 13
                        }, this)
                    ]
                }, phaseEndsAt ?? 'role-reveal', true, {
                    fileName: "[project]/components/game/RoleRevealScene.tsx",
                    lineNumber: 38,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-64"
                }, void 0, false, {
                    fileName: "[project]/components/game/RoleRevealScene.tsx",
                    lineNumber: 82,
                    columnNumber: 11
                }, this),
                endGameButton ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "pt-10",
                    children: endGameButton
                }, void 0, false, {
                    fileName: "[project]/components/game/RoleRevealScene.tsx",
                    lineNumber: 84,
                    columnNumber: 26
                }, this) : null
            ]
        }, void 0, true, {
            fileName: "[project]/components/game/RoleRevealScene.tsx",
            lineNumber: 36,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/game/RoleRevealScene.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_c = RoleRevealScene;
var _c;
__turbopack_context__.k.register(_c, "RoleRevealScene");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/useGamePhaseAnimation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GAME_PHASE_ANIMATION_MS",
    ()=>GAME_PHASE_ANIMATION_MS,
    "useGamePhaseAnimation",
    ()=>useGamePhaseAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const GAME_PHASE_ANIMATION_MS = {
    roleTitleLead: 1400,
    roleRevealHold: 3000,
    roleRevealPostPause: 1500,
    roleRevealFade: 700,
    fadeIn: 700,
    transitionKickoff: 30,
    nightResultsLine1Lead: 1100,
    nightResultsLine2Lead: 2200,
    nightResultsNotebookLead: 4200,
    nightResultsPostInfoPause: 3000,
    nightResultsFade: 700,
    phaseTransitionFade: 1200,
    nightResultsLineGap: 700
};
function useGamePhaseAnimation({ currentPhase, currentPhaseEndsAt, currentDayNumber, nightResultsSequenceKey, revealDeathUserId }) {
    _s();
    const [revealState, setRevealState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('hidden');
    const [nightResultRevealState, setNightResultRevealState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('hidden');
    const [phaseOverlayState, setPhaseOverlayState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        mode: 'hidden',
        key: 0
    });
    const lastNightResultsSequenceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const previousPhaseRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGamePhaseAnimation.useEffect": ()=>{
            /* -------------------------------------------------------------------------
       Role reveal sequencing
    ------------------------------------------------------------------------- */ if (currentPhase !== 'roleReveal') {
                const resetId = setTimeout({
                    "useGamePhaseAnimation.useEffect.resetId": ()=>{
                        setRevealState('hidden');
                    }
                }["useGamePhaseAnimation.useEffect.resetId"], 0);
                return ({
                    "useGamePhaseAnimation.useEffect": ()=>clearTimeout(resetId)
                })["useGamePhaseAnimation.useEffect"];
            }
            const showTitleId = setTimeout({
                "useGamePhaseAnimation.useEffect.showTitleId": ()=>{
                    setRevealState('titlePre');
                }
            }["useGamePhaseAnimation.useEffect.showTitleId"], 0);
            const showTitleFadeId = setTimeout({
                "useGamePhaseAnimation.useEffect.showTitleFadeId": ()=>{
                    setRevealState('title');
                }
            }["useGamePhaseAnimation.useEffect.showTitleFadeId"], GAME_PHASE_ANIMATION_MS.transitionKickoff);
            const showRoleId = setTimeout({
                "useGamePhaseAnimation.useEffect.showRoleId": ()=>{
                    setRevealState('rolePre');
                }
            }["useGamePhaseAnimation.useEffect.showRoleId"], GAME_PHASE_ANIMATION_MS.roleTitleLead);
            const showRoleFadeId = setTimeout({
                "useGamePhaseAnimation.useEffect.showRoleFadeId": ()=>{
                    setRevealState('role');
                }
            }["useGamePhaseAnimation.useEffect.showRoleFadeId"], GAME_PHASE_ANIMATION_MS.roleTitleLead + GAME_PHASE_ANIMATION_MS.transitionKickoff);
            const fadeOutDelay = currentPhaseEndsAt ? Math.max(0, currentPhaseEndsAt - Date.now() - GAME_PHASE_ANIMATION_MS.roleRevealFade) : GAME_PHASE_ANIMATION_MS.roleTitleLead + GAME_PHASE_ANIMATION_MS.roleRevealHold + GAME_PHASE_ANIMATION_MS.roleRevealPostPause;
            const fadeId = setTimeout({
                "useGamePhaseAnimation.useEffect.fadeId": ()=>{
                    setRevealState('fading');
                }
            }["useGamePhaseAnimation.useEffect.fadeId"], fadeOutDelay);
            return ({
                "useGamePhaseAnimation.useEffect": ()=>{
                    clearTimeout(showTitleId);
                    clearTimeout(showTitleFadeId);
                    clearTimeout(showRoleId);
                    clearTimeout(showRoleFadeId);
                    clearTimeout(fadeId);
                }
            })["useGamePhaseAnimation.useEffect"];
        }
    }["useGamePhaseAnimation.useEffect"], [
        currentPhase,
        currentPhaseEndsAt
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGamePhaseAnimation.useEffect": ()=>{
            /* -------------------------------------------------------------------------
       Night results sequencing

       Uses `nightResultsSequenceKey` to avoid re-scheduling timers when we
       receive duplicate lobby snapshots for the same reveal.
    ------------------------------------------------------------------------- */ if (currentPhase !== 'nightResults') {
                lastNightResultsSequenceRef.current = null;
                const resetId = setTimeout({
                    "useGamePhaseAnimation.useEffect.resetId": ()=>{
                        setNightResultRevealState('hidden');
                    }
                }["useGamePhaseAnimation.useEffect.resetId"], 0);
                return ({
                    "useGamePhaseAnimation.useEffect": ()=>clearTimeout(resetId)
                })["useGamePhaseAnimation.useEffect"];
            }
            const scheduleKey = `${nightResultsSequenceKey}-${currentPhaseEndsAt ?? 'pending'}`;
            if (lastNightResultsSequenceRef.current === scheduleKey) {
                return;
            }
            lastNightResultsSequenceRef.current = scheduleKey;
            const resetToHiddenId = setTimeout({
                "useGamePhaseAnimation.useEffect.resetToHiddenId": ()=>{
                    setNightResultRevealState('hidden');
                }
            }["useGamePhaseAnimation.useEffect.resetToHiddenId"], 0);
            const now = Date.now();
            const safePhaseEndsAt = currentPhaseEndsAt ?? now + GAME_PHASE_ANIMATION_MS.nightResultsNotebookLead + GAME_PHASE_ANIMATION_MS.nightResultsPostInfoPause;
            const transitionLeadMs = Math.max(GAME_PHASE_ANIMATION_MS.nightResultsFade, GAME_PHASE_ANIMATION_MS.phaseTransitionFade);
            const transitionStartAt = safePhaseEndsAt - transitionLeadMs;
            const notebookAt = revealDeathUserId ? transitionStartAt - GAME_PHASE_ANIMATION_MS.nightResultsPostInfoPause : null;
            const desiredLine2At = now + GAME_PHASE_ANIMATION_MS.nightResultsLine2Lead;
            const line2At = notebookAt ? Math.min(desiredLine2At, notebookAt - GAME_PHASE_ANIMATION_MS.nightResultsLineGap) : desiredLine2At;
            const line1At = Math.min(now + GAME_PHASE_ANIMATION_MS.nightResultsLine1Lead, line2At - GAME_PHASE_ANIMATION_MS.nightResultsLineGap);
            const headingAt = Math.min(now + GAME_PHASE_ANIMATION_MS.transitionKickoff, line1At - 400);
            const headingDelay = Math.max(0, headingAt - now);
            const line1Delay = Math.max(0, line1At - now);
            const line2Delay = Math.max(0, line2At - now);
            const notebookDelay = notebookAt ? Math.max(0, notebookAt - now) : null;
            const showHeadingId = setTimeout({
                "useGamePhaseAnimation.useEffect.showHeadingId": ()=>{
                    setNightResultRevealState('heading');
                }
            }["useGamePhaseAnimation.useEffect.showHeadingId"], headingDelay);
            const showLine1Id = setTimeout({
                "useGamePhaseAnimation.useEffect.showLine1Id": ()=>{
                    setNightResultRevealState('line1');
                }
            }["useGamePhaseAnimation.useEffect.showLine1Id"], line1Delay);
            const showLine2Id = setTimeout({
                "useGamePhaseAnimation.useEffect.showLine2Id": ()=>{
                    setNightResultRevealState('line2');
                }
            }["useGamePhaseAnimation.useEffect.showLine2Id"], line2Delay);
            const showNotebookId = revealDeathUserId && notebookDelay !== null ? setTimeout({
                "useGamePhaseAnimation.useEffect": ()=>{
                    setNightResultRevealState('notebook');
                }
            }["useGamePhaseAnimation.useEffect"], notebookDelay) : null;
            const fadeOutDelay = currentPhaseEndsAt ? Math.max(0, currentPhaseEndsAt - Date.now() - GAME_PHASE_ANIMATION_MS.nightResultsFade) : GAME_PHASE_ANIMATION_MS.nightResultsLine2Lead + 1200;
            const fadeId = setTimeout({
                "useGamePhaseAnimation.useEffect.fadeId": ()=>{
                    setNightResultRevealState('fading');
                }
            }["useGamePhaseAnimation.useEffect.fadeId"], fadeOutDelay);
            return ({
                "useGamePhaseAnimation.useEffect": ()=>{
                    clearTimeout(resetToHiddenId);
                    clearTimeout(showHeadingId);
                    clearTimeout(showLine1Id);
                    clearTimeout(showLine2Id);
                    if (showNotebookId) {
                        clearTimeout(showNotebookId);
                    }
                    clearTimeout(fadeId);
                }
            })["useGamePhaseAnimation.useEffect"];
        }
    }["useGamePhaseAnimation.useEffect"], [
        currentPhase,
        currentPhaseEndsAt,
        nightResultsSequenceKey,
        revealDeathUserId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGamePhaseAnimation.useEffect": ()=>{
            /* -------------------------------------------------------------------------
       Fade-in overlay (on phase entry)
    ------------------------------------------------------------------------- */ const previousPhase = previousPhaseRef.current;
            previousPhaseRef.current = currentPhase;
            const skipFadeIn = previousPhase === 'day' && currentPhase === 'vote' && (currentDayNumber ?? 0) > 0 || previousPhase === 'night' && currentPhase === 'nightActionResults';
            if (skipFadeIn) return;
            const startId = setTimeout({
                "useGamePhaseAnimation.useEffect.startId": ()=>{
                    setPhaseOverlayState({
                        "useGamePhaseAnimation.useEffect.startId": (previous)=>({
                                mode: 'fadeIn',
                                key: previous.key + 1
                            })
                    }["useGamePhaseAnimation.useEffect.startId"]);
                }
            }["useGamePhaseAnimation.useEffect.startId"], 0);
            const endId = setTimeout({
                "useGamePhaseAnimation.useEffect.endId": ()=>{
                    setPhaseOverlayState({
                        "useGamePhaseAnimation.useEffect.endId": (previous)=>previous.mode === 'fadeIn' ? {
                                ...previous,
                                mode: 'hidden'
                            } : previous
                    }["useGamePhaseAnimation.useEffect.endId"]);
                }
            }["useGamePhaseAnimation.useEffect.endId"], GAME_PHASE_ANIMATION_MS.phaseTransitionFade);
            return ({
                "useGamePhaseAnimation.useEffect": ()=>{
                    clearTimeout(startId);
                    clearTimeout(endId);
                }
            })["useGamePhaseAnimation.useEffect"];
        }
    }["useGamePhaseAnimation.useEffect"], [
        currentDayNumber,
        currentPhase
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGamePhaseAnimation.useEffect": ()=>{
            /* -------------------------------------------------------------------------
       Fade-out overlay (on phase exit)

       Some phases (day, night) intentionally do not fade out to keep the
       game flow snappy and reduce perceived "stutter" between snapshots.
    ------------------------------------------------------------------------- */ if (!currentPhaseEndsAt) return;
            const skipFadeOut = currentPhase === 'day' && (currentDayNumber ?? 0) > 0 || currentPhase === 'night';
            if (skipFadeOut) return;
            // Start the fade when the timer would display "0" (sub-1s remaining),
            // rather than at "1". This avoids the fade appearing to begin early.
            const delay = Math.max(0, currentPhaseEndsAt - Date.now() - 999);
            const startId = setTimeout({
                "useGamePhaseAnimation.useEffect.startId": ()=>{
                    setPhaseOverlayState({
                        "useGamePhaseAnimation.useEffect.startId": (previous)=>({
                                mode: 'fadeOut',
                                key: previous.key + 1
                            })
                    }["useGamePhaseAnimation.useEffect.startId"]);
                }
            }["useGamePhaseAnimation.useEffect.startId"], delay);
            return ({
                "useGamePhaseAnimation.useEffect": ()=>clearTimeout(startId)
            })["useGamePhaseAnimation.useEffect"];
        }
    }["useGamePhaseAnimation.useEffect"], [
        currentDayNumber,
        currentPhase,
        currentPhaseEndsAt
    ]);
    return {
        revealState,
        nightResultRevealState,
        phaseOverlayState
    };
}
_s(useGamePhaseAnimation, "j8DaQ0MGhy+Law9Y8hBR3/dNY3g=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/selectors/gameSnapshotSelectors.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSelectedNightTargetUserId",
    ()=>getSelectedNightTargetUserId
]);
'use client';
const getSelectedNightTargetUserId = (game)=>{
    switch(game.role){
        case 'AlphaWolf':
        case 'Werewolf':
        case 'Hunter':
            return game.nightKillTargetUserId ?? null;
        case 'Escort':
            return game.escortVisitTargetUserId ?? null;
        case 'Bodyguard':
            return game.bodyguardGuardTargetUserId ?? null;
        case 'Doctor':
            return game.doctorProtectTargetUserId ?? null;
        case 'Tracker':
            return game.trackerWatchTargetUserId ?? null;
        case 'Lookout':
            return game.lookoutWatchTargetUserId ?? null;
        case 'Investigator':
            return game.investigatorVisitTargetUserId ?? null;
        case 'Framer':
            return game.framerTargetUserId ?? null;
        case 'Prowler':
            return game.prowlerTargetUserId ?? null;
        case 'Snatcher':
            return game.snatcherTargetUserId ?? null;
        case 'Cursed':
            return game.cursedTargetUserId ?? null;
        case 'Mimic':
            return game.mimicTargetUserId ?? null;
        default:
            return null;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/routes/routePaths.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Route Path Helpers

   Small helpers for building internal app routes consistently.
   Centralizes `encodeURIComponent` so it isn't repeated across pages/hooks.
============================================================================= */ /* ---------------------------------------------------------------------------
   Lobby Routes
--------------------------------------------------------------------------- */ /* ---------------------------------------------------------------------------
   lobbyPath(lobbyName)

   Base lobby route for a given lobby name.
--------------------------------------------------------------------------- */ __turbopack_context__.s([
    "gamePath",
    ()=>gamePath,
    "lobbyPath",
    ()=>lobbyPath,
    "resultsPath",
    ()=>resultsPath
]);
const lobbyPath = (lobbyName)=>`/lobby/${encodeURIComponent(lobbyName)}`;
const gamePath = (lobbyName)=>`${lobbyPath(lobbyName)}/game`;
const resultsPath = (lobbyName)=>`${lobbyPath(lobbyName)}/results`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/useLobbyGameState.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLobbyGameState",
    ()=>useLobbyGameState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/actions/gameSocketActions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$gameSnapshotSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/selectors/gameSnapshotSelectors.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useNowTicker.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$routePaths$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/routes/routePaths.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function useLobbyGameState({ lobbyName, lobbyInfo, navigation }) {
    _s();
    const nowMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNowTicker"])(!!lobbyInfo?.startingAt, 250);
    const navigatedToResultsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const lastLobbySyncKeyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    /* ---------------------------------------------------------------------------
     Game state derived from `game:init`
  --------------------------------------------------------------------------- */ const [phase, setPhase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('lobby');
    const [dayNumber, setDayNumber] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [nightNumber, setNightNumber] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [phaseEndsAt, setPhaseEndsAt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentNightDeathReveal, setCurrentNightDeathReveal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentEliminationResult, setCurrentEliminationResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [role, setRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [gameStarted, setGameStarted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [gameHostUserId, setGameHostUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [canWriteNotebook, setCanWriteNotebook] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [werewolfUserIds, setWerewolfUserIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [hunterShotsRemaining, setHunterShotsRemaining] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [trapperAlertsRemaining, setTrapperAlertsRemaining] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [trapperAlertActive, setTrapperAlertActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [doctorSelfProtectUsed, setDoctorSelfProtectUsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [executionerTargetName, setExecutionerTargetName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [executionerTargetUserId, setExecutionerTargetUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    /* ---------------------------------------------------------------------------
     UI-only state
  --------------------------------------------------------------------------- */ const [viewingNotebook, setViewingNotebook] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedNightActionTargetId, setSelectedNightActionTargetId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedVoteTargetId, setSelectedVoteTargetId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    /* ---------------------------------------------------------------------------
     applyCommonSnapshot(game)

     Applies the subset of snapshot fields that we want to re-sync frequently
     (role state, selections, per-role resources).

     Used on:
     - initial load
     - lobby realtime updates (refresh/reconnect resilience)
  --------------------------------------------------------------------------- */ const applyCommonSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useLobbyGameState.useCallback[applyCommonSnapshot]": (game)=>{
            setRole(game.role);
            setCanWriteNotebook(game.canWriteNotebook);
            setWerewolfUserIds(game.werewolfUserIds ?? []);
            setHunterShotsRemaining(game.hunterShotsRemaining ?? 0);
            setTrapperAlertsRemaining(game.trapperAlertsRemaining ?? 0);
            setTrapperAlertActive(game.trapperAlertActive ?? false);
            setDoctorSelfProtectUsed(game.doctorSelfProtectUsed ?? false);
            setSelectedNightActionTargetId((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$gameSnapshotSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSelectedNightTargetUserId"])(game));
            setExecutionerTargetName(game.executionerTargetName ?? null);
            setExecutionerTargetUserId(game.executionerTargetUserId ?? null);
            setGameHostUserId(game.hostUserId);
        }
    }["useLobbyGameState.useCallback[applyCommonSnapshot]"], []);
    /* ---------------------------------------------------------------------------
     applyFullSnapshot(game)

     Applies the full game snapshot including phase timing + reveal state.
     Typically only needed on the first load (or a full refresh).
  --------------------------------------------------------------------------- */ const applyFullSnapshot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useLobbyGameState.useCallback[applyFullSnapshot]": (game)=>{
            setGameStarted(game.started);
            setPhase(game.phase);
            setDayNumber(game.dayNumber);
            setNightNumber(game.nightNumber);
            setPhaseEndsAt(game.phaseEndsAt);
            setCurrentNightDeathReveal(game.currentNightDeathReveal ?? null);
            setCurrentEliminationResult(game.currentEliminationResult ?? null);
            applyCommonSnapshot(game);
        }
    }["useLobbyGameState.useCallback[applyFullSnapshot]"], [
        applyCommonSnapshot
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyGameState.useEffect": ()=>{
            if (!lobbyName) return;
            /* -------------------------------------------------------------------------
       Initial authoritative snapshot
    ------------------------------------------------------------------------- */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initGame"])(lobbyName, {
                "useLobbyGameState.useEffect": (response)=>{
                    if (!response?.ok || !response.game) {
                        console.error(response?.error ?? 'Failed to initialize game');
                        return;
                    }
                    applyFullSnapshot(response.game);
                }
            }["useLobbyGameState.useEffect"]);
        }
    }["useLobbyGameState.useEffect"], [
        applyFullSnapshot,
        lobbyName
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyGameState.useEffect": ()=>{
            if (!lobbyName || !lobbyInfo) return;
            /* -------------------------------------------------------------------------
       Refresh common fields (throttled by a lobby-derived key)

       `lobbyInfo` updates frequently (presence counts, timers, etc.). Calling
       `game:init` on *every* lobby snapshot can spam the server and produce
       noisy logs.

       We only re-fetch the game snapshot when a "game-relevant" lobby field
       changes (phase transitions, reveals, round numbers). This still keeps
       role-specific state accurate across refreshes/reconnects without
       over-requesting.
    ------------------------------------------------------------------------- */ const eliminationKey = lobbyInfo.currentEliminationResult?.noElimination === true ? 'none' : lobbyInfo.currentEliminationResult && 'userId' in lobbyInfo.currentEliminationResult ? lobbyInfo.currentEliminationResult.userId : 'waiting';
            const nextKey = [
                lobbyInfo.started ? '1' : '0',
                lobbyInfo.gamePhase,
                lobbyInfo.dayNumber ?? 'null',
                lobbyInfo.nightNumber ?? 'null',
                lobbyInfo.phaseEndsAt ?? 'null',
                lobbyInfo.currentNightDeathReveal?.userId ?? 'none',
                eliminationKey
            ].join('|');
            if (lastLobbySyncKeyRef.current === nextKey) return;
            lastLobbySyncKeyRef.current = nextKey;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initGame"])(lobbyName, {
                "useLobbyGameState.useEffect": (response)=>{
                    if (!response?.ok || !response.game) return;
                    applyCommonSnapshot(response.game);
                }
            }["useLobbyGameState.useEffect"]);
        }
    }["useLobbyGameState.useEffect"], [
        applyCommonSnapshot,
        lobbyInfo,
        lobbyName
    ]);
    const started = lobbyInfo?.started ?? gameStarted;
    const currentPhase = lobbyInfo?.gamePhase ?? phase;
    const effectiveDisplayPhase = currentPhase === 'nightActionResults' ? 'night' : currentPhase;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyGameState.useEffect": ()=>{
            if (!lobbyName) return;
            if (lobbyInfo?.gamePhase !== 'gameResults') return;
            if (navigatedToResultsRef.current) return;
            navigatedToResultsRef.current = true;
            // Give the results overlay time to fade out before route transition.
            const id = setTimeout({
                "useLobbyGameState.useEffect.id": ()=>{
                    navigation.replace((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$routePaths$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resultsPath"])(lobbyName));
                }
            }["useLobbyGameState.useEffect.id"], 900);
            return ({
                "useLobbyGameState.useEffect": ()=>clearTimeout(id)
            })["useLobbyGameState.useEffect"];
        }
    }["useLobbyGameState.useEffect"], [
        lobbyInfo?.gamePhase,
        lobbyName,
        navigation
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyGameState.useEffect": ()=>{
            if (effectiveDisplayPhase === 'day' || effectiveDisplayPhase === 'night') return;
            const id = setTimeout({
                "useLobbyGameState.useEffect.id": ()=>{
                    setViewingNotebook(null);
                }
            }["useLobbyGameState.useEffect.id"], 0);
            return ({
                "useLobbyGameState.useEffect": ()=>clearTimeout(id)
            })["useLobbyGameState.useEffect"];
        }
    }["useLobbyGameState.useEffect"], [
        effectiveDisplayPhase
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyGameState.useEffect": ()=>{
            const id = setTimeout({
                "useLobbyGameState.useEffect.id": ()=>{
                    if (currentPhase !== 'vote') setSelectedVoteTargetId(null);
                    if (effectiveDisplayPhase !== 'night') setSelectedNightActionTargetId(null);
                }
            }["useLobbyGameState.useEffect.id"], 0);
            return ({
                "useLobbyGameState.useEffect": ()=>clearTimeout(id)
            })["useLobbyGameState.useEffect"];
        }
    }["useLobbyGameState.useEffect"], [
        currentPhase,
        effectiveDisplayPhase
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyGameState.useEffect": ()=>{
            if (started) return;
            if (!lobbyName) return;
            if (lobbyInfo?.startingAt) return;
            navigation.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$routePaths$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lobbyPath"])(lobbyName));
        }
    }["useLobbyGameState.useEffect"], [
        lobbyInfo?.startingAt,
        navigation,
        lobbyName,
        started
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useLobbyGameState.useMemo": ()=>({
                nowMs,
                started,
                effectiveDisplayPhase,
                // server-derived state
                phase,
                dayNumber,
                nightNumber,
                phaseEndsAt,
                currentNightDeathReveal,
                currentEliminationResult,
                role,
                gameStarted,
                gameHostUserId,
                canWriteNotebook,
                werewolfUserIds,
                hunterShotsRemaining,
                trapperAlertsRemaining,
                trapperAlertActive,
                doctorSelfProtectUsed,
                executionerTargetName,
                executionerTargetUserId,
                // ui state
                viewingNotebook,
                setViewingNotebook,
                selectedNightActionTargetId,
                setSelectedNightActionTargetId,
                selectedVoteTargetId,
                setSelectedVoteTargetId
            })
    }["useLobbyGameState.useMemo"], [
        canWriteNotebook,
        currentEliminationResult,
        currentNightDeathReveal,
        dayNumber,
        doctorSelfProtectUsed,
        effectiveDisplayPhase,
        executionerTargetName,
        executionerTargetUserId,
        gameHostUserId,
        gameStarted,
        hunterShotsRemaining,
        nightNumber,
        nowMs,
        phase,
        phaseEndsAt,
        role,
        selectedNightActionTargetId,
        selectedVoteTargetId,
        started,
        trapperAlertActive,
        trapperAlertsRemaining,
        viewingNotebook,
        werewolfUserIds
    ]);
}
_s(useLobbyGameState, "4GVKpMpRrIMD57VNr+WMlbZzL4U=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useNowTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNowTicker"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/useLobbyRealtime.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLobbyRealtime",
    ()=>useLobbyRealtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useLobbyRealtime(lobbyName) {
    _s();
    const [lobbyInfo, setLobbyInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useLobbyRealtime.useEffect": ()=>{
            if (!lobbyName) return;
            /* -------------------------------------------------------------------------
       Realtime Lobby State

       - `initiateLobby` returns the full current snapshot (reconnect-friendly)
       - `update` pushes snapshots as the server mutates the lobby
    ------------------------------------------------------------------------- */ let active = true;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
            const requestSnapshot = {
                "useLobbyRealtime.useEffect.requestSnapshot": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].emit('initiateLobby', {
                        lobbyName
                    }, {
                        "useLobbyRealtime.useEffect.requestSnapshot": (response)=>{
                            if (!active) return;
                            if (!response?.ok) {
                                // If the server restarted, in-memory lobbies are lost. Clear local state so
                                // UI doesn't keep rendering stale lobby info.
                                setLobbyInfo(null);
                                return;
                            }
                            setLobbyInfo(response.lobbyInfo);
                        }
                    }["useLobbyRealtime.useEffect.requestSnapshot"]);
                }
            }["useLobbyRealtime.useEffect.requestSnapshot"];
            // Initial snapshot (and used again on reconnect). Only emit once connected to
            // avoid queuing a snapshot request *and* also re-requesting on "connect".
            if (__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].connected) {
                requestSnapshot();
            }
            const onUpdate = {
                "useLobbyRealtime.useEffect.onUpdate": (data)=>{
                    if (!active) return;
                    setLobbyInfo(data);
                }
            }["useLobbyRealtime.useEffect.onUpdate"];
            /* -----------------------------------------------------------------------
       Reconnect Resilience

       When the socket reconnects (after a server restart or transient network
       issue), re-request the authoritative lobby snapshot.
    ----------------------------------------------------------------------- */ __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].on('connect', requestSnapshot);
            /* -----------------------------------------------------------------------
       Server Push Subscription: `update`

       Payload: full `LobbyView` snapshot.
       Why: keeps lobby pages in sync without polling.
       Cleanup: remove listener on unmount / lobby change.
    ----------------------------------------------------------------------- */ __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].on('update', onUpdate);
            return ({
                "useLobbyRealtime.useEffect": ()=>{
                    active = false;
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].off('connect', requestSnapshot);
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].off('update', onUpdate);
                }
            })["useLobbyRealtime.useEffect"];
        }
    }["useLobbyRealtime.useEffect"], [
        lobbyName
    ]);
    return {
        lobbyInfo,
        setLobbyInfo
    };
}
_s(useLobbyRealtime, "Ymx/JLsCIk0pSOgvJmchFBHIqmw=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/hooks/usePresenceView.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePresenceView",
    ()=>usePresenceView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/socket/utils.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function usePresenceView(lobbyName, view) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePresenceView.useEffect": ()=>{
            if (!lobbyName) return;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["connectSocketIfNeeded"])();
            // Idempotent: the server treats this as a state update (not a "do once" action).
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$socket$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["socket"].emit('presence:setView', {
                lobbyName,
                view
            });
        }
    }["usePresenceView.useEffect"], [
        lobbyName,
        view
    ]);
}
_s(usePresenceView, "OD7bBpZva5O2jO+Puf00hKivP7c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/selectors/gameUiSelectors.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildChatRefreshKey",
    ()=>buildChatRefreshKey,
    "buildNightResultsSequenceKey",
    ()=>buildNightResultsSequenceKey,
    "sortMembersAliveFirst",
    ()=>sortMembersAliveFirst
]);
'use client';
const sortMembersAliveFirst = (members)=>{
    const alive = [];
    const dead = [];
    for (const member of members){
        (member.alive ? alive : dead).push(member);
    }
    return [
        ...alive,
        ...dead
    ];
};
const buildNightResultsSequenceKey = (revealDeathUserId, currentNightNumber)=>revealDeathUserId ? `death-${revealDeathUserId}` : `none-${currentNightNumber ?? 0}`;
const buildChatRefreshKey = ({ currentPhase, roleName, selfAlive, started })=>`${currentPhase}:${roleName}:${selfAlive ? 'alive' : 'dead'}:${started ? 'started' : 'stopped'}`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/selectors/lobbyUiSelectors.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_PHASE_DURATIONS",
    ()=>DEFAULT_PHASE_DURATIONS,
    "buildLobbySettingsPayload",
    ()=>buildLobbySettingsPayload,
    "getMinWerewolves",
    ()=>getMinWerewolves,
    "getStartingRemainingSeconds",
    ()=>getStartingRemainingSeconds
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/formatters/timeFormatters.ts [app-client] (ecmascript)");
'use client';
;
const DEFAULT_PHASE_DURATIONS = {
    daySeconds: 10,
    nightSeconds: 10,
    voteSeconds: 10
};
const getMinWerewolves = (specialRolesEnabled)=>specialRolesEnabled ? 2 : 1;
const getStartingRemainingSeconds = (startingAt, nowMs)=>startingAt && nowMs !== null ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatters$2f$timeFormatters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRemainingSecondsCeil"])(startingAt, nowMs) : null;
const buildLobbySettingsPayload = (lobbyInfo, overrides = {})=>{
    const nextSpecial = overrides.specialRolesEnabled ?? lobbyInfo.specialRolesEnabled ?? false;
    const nextNeutralRaw = overrides.neutralRolesEnabled ?? lobbyInfo.neutralRolesEnabled ?? false;
    // Neutral roles are only available when special roles are enabled.
    const nextNeutral = nextSpecial ? nextNeutralRaw : false;
    const minWerewolves = getMinWerewolves(nextSpecial);
    const desiredWerewolves = overrides.werewolfCount ?? lobbyInfo.werewolfCount ?? minWerewolves;
    const nextWerewolves = Math.max(minWerewolves, desiredWerewolves);
    return {
        werewolfCount: nextWerewolves,
        specialRolesEnabled: nextSpecial,
        neutralRolesEnabled: nextNeutral,
        phaseDurations: overrides.phaseDurations ?? lobbyInfo.phaseDurations ?? DEFAULT_PHASE_DURATIONS
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/routes/lobbyName.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* =============================================================================
   Lobby Name Normalization (Client)

   Next.js route params are usually decoded, but in practice we can still see
   URL-encoded lobby names (or even double-encoded names) depending on how a
   user navigated (copy/paste, redirects, manual edits).

   If the client emits the wrong lobby key (ex: "My%2520Lobby"), the server will
   fail to find the lobby and return "Lobby does not exist".

   This helper gives pages/hooks a single, predictable way to derive the
   canonical lobby key from a route param.
============================================================================= */ __turbopack_context__.s([
    "normalizeLobbyNameParam",
    ()=>normalizeLobbyNameParam
]);
const normalizeLobbyNameParam = (value)=>{
    if (typeof value !== 'string') return undefined;
    let next = value;
    // Guard against double-encoding (ex: "%2520" -> "%20" -> " ").
    for(let i = 0; i < 2; i++){
        if (!next.includes('%')) break;
        try {
            const decoded = decodeURIComponent(next);
            if (decoded === next) break;
            next = decoded;
        } catch  {
            break;
        }
    }
    const trimmed = next.trim();
    return trimmed || undefined;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lobby/[lobbyName]/game/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LobbyGamePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$EliminationResultsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/EliminationResultsCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$EndGameScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/EndGameScene.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameFloatingPanels$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/GameFloatingPanels.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameOverlays$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/GameOverlays.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameStartingScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/GameStartingScene.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$MemberActionRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/MemberActionRow.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$NightResultsScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/NightResultsScene.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$PhaseTimer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/PhaseTimer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$PlayerList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/PlayerList.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$PlayerRoleCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/PlayerRoleCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$RoleRevealScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/game/RoleRevealScene.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/actions/gameSocketActions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useGamePhaseAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useGamePhaseAnimation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyGameState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useLobbyGameState.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyRealtime$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/useLobbyRealtime.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$usePresenceView$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/hooks/usePresenceView.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$gameUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/selectors/gameUiSelectors.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/selectors/lobbyUiSelectors.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$lobbyName$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/routes/lobbyName.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/models/roles.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/react.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function LobbyGamePage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { data: session } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"])();
    const { lobbyName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const lobbyNameParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$routes$2f$lobbyName$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeLobbyNameParam"])(typeof lobbyName === 'string' ? lobbyName : undefined);
    // Subscribe using the param-derived name so the hook doesn't thrash when the
    // server later returns the canonical lobby name.
    const { lobbyInfo } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyRealtime$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLobbyRealtime"])(lobbyNameParam);
    // Canonical key to use for *emits* (prevents double-encoded lobby keys).
    const lobbyNameKey = lobbyInfo?.lobbyName ?? lobbyNameParam;
    /* -----------------------------------------------------------------------
     Presence Tracking

     Lets the server know this user is actively viewing the game screen.
  ----------------------------------------------------------------------- */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$usePresenceView$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePresenceView"])(lobbyNameKey, 'game');
    /* -----------------------------------------------------------------------
     Orchestrated Game UI State

     `useLobbyGameState` owns the "fetch + reconcile + redirect" logic so this
     page can focus on rendering.
  ----------------------------------------------------------------------- */ const { nowMs, started, effectiveDisplayPhase, phase, dayNumber, nightNumber, phaseEndsAt, currentNightDeathReveal, currentEliminationResult, role, gameHostUserId, canWriteNotebook, werewolfUserIds, hunterShotsRemaining, trapperAlertsRemaining, trapperAlertActive, doctorSelfProtectUsed, executionerTargetName, executionerTargetUserId, viewingNotebook, setViewingNotebook, selectedNightActionTargetId, setSelectedNightActionTargetId, selectedVoteTargetId, setSelectedVoteTargetId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyGameState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLobbyGameState"])({
        lobbyName: lobbyNameKey,
        lobbyInfo,
        navigation: router
    });
    /* -----------------------------------------------------------------------
     Authoritative Phase Snapshot

     Lobby realtime (`useLobbyRealtime`) is the source of truth for phase and
     membership; `useLobbyGameState` provides fallback state for resilience.
  ----------------------------------------------------------------------- */ const currentPhase = lobbyInfo?.gamePhase ?? phase;
    const currentDayNumber = lobbyInfo?.dayNumber ?? dayNumber;
    const currentNightNumber = lobbyInfo?.nightNumber ?? nightNumber;
    const currentPhaseEndsAt = lobbyInfo?.phaseEndsAt ?? phaseEndsAt;
    const revealDeath = lobbyInfo?.currentNightDeathReveal ?? currentNightDeathReveal;
    const revealDeathUserId = revealDeath?.userId ?? null;
    /* -----------------------------------------------------------------------
     Night Results Sequence Key

     Used to restart the animated night-results sequence when the revealed death
     changes (without restarting on duplicate snapshots).
  ----------------------------------------------------------------------- */ const nightResultsSequenceKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$gameUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildNightResultsSequenceKey"])(revealDeathUserId, currentNightNumber);
    const eliminationResult = lobbyInfo?.currentEliminationResult ?? currentEliminationResult;
    const hostUserId = lobbyInfo?.hostUserId ?? gameHostUserId;
    /* -----------------------------------------------------------------------
     Local Player + Member Ordering

     We keep alive players at the top for readability, while preserving the
     original server ordering within each alive/dead group.
  ----------------------------------------------------------------------- */ const currentUserId = session?.user?.id;
    const selfMember = (lobbyInfo?.members ?? []).find((member)=>member.userId === currentUserId);
    const sortedMembers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$gameUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortMembersAliveFirst"])(lobbyInfo?.members ?? []);
    const selfAlive = selfMember?.alive ?? true;
    const startingRemainingSeconds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStartingRemainingSeconds"])(lobbyInfo?.startingAt, nowMs);
    const phaseDurations = lobbyInfo?.phaseDurations ?? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PHASE_DURATIONS"];
    const phaseDurationMs = currentPhase === 'day' ? (phaseDurations.daySeconds ?? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PHASE_DURATIONS"].daySeconds) * 1000 : currentPhase === 'night' ? (phaseDurations.nightSeconds ?? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PHASE_DURATIONS"].nightSeconds) * 1000 : currentPhase === 'vote' ? (phaseDurations.voteSeconds ?? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$lobbyUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_PHASE_DURATIONS"].voteSeconds) * 1000 : null;
    /* -----------------------------------------------------------------------
     Phase Animations

     Drives cinematic fades + role/night reveal animations based on the
     authoritative phase timers (`phaseEndsAt`) sent by the server.
  ----------------------------------------------------------------------- */ const { revealState, nightResultRevealState, phaseOverlayState } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useGamePhaseAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGamePhaseAnimation"])({
        currentPhase,
        currentPhaseEndsAt,
        currentDayNumber,
        nightResultsSequenceKey,
        revealDeathUserId
    });
    const isDayCyclePhase = effectiveDisplayPhase === 'day' || effectiveDisplayPhase === 'vote' || effectiveDisplayPhase === 'eliminationResults';
    const isNightCyclePhase = effectiveDisplayPhase === 'night';
    const roleName = role ?? 'Unknown';
    const roleInfo = role && role in __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"] ? __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROLES"][role] : null;
    const roleDisplayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$roles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRoleDisplayName"])(roleName);
    const winningFaction = lobbyInfo?.gameResults?.winningFaction ?? null;
    const didWin = (()=>{
        if (!roleInfo) return null;
        if (!winningFaction) return roleInfo.faction === 'Village';
        if (winningFaction === 'Village') return roleInfo.faction === 'Village';
        if (winningFaction === 'Enemy') return roleInfo.faction === 'Enemy';
        if (winningFaction === 'Jester') return roleName === 'Jester';
        if (winningFaction === 'Executioner') return roleName === 'Executioner';
        return null;
    })();
    const phaseSubLabel = effectiveDisplayPhase === 'day' ? 'The village gathers by torchlight.' : effectiveDisplayPhase === 'vote' ? 'Whispers turn to accusations.' : effectiveDisplayPhase === 'eliminationResults' ? 'The village passes judgment.' : effectiveDisplayPhase === 'night' ? 'Shadows deepen and choices are made in secret.' : null;
    const nightInstruction = (()=>{
        if (!selfAlive) return 'You are dead. You cannot act, but you can observe.';
        const nightInstructionContext = {
            hunterShotsRemaining,
            trapperAlertsRemaining,
            trapperAlertActive
        };
        if (typeof roleInfo?.nightInstruction === 'function') {
            return roleInfo.nightInstruction(nightInstructionContext);
        }
        return roleInfo?.nightInstruction ?? 'You have no night action tonight.';
    })();
    const phaseSubInstruction = effectiveDisplayPhase === 'day' ? (currentDayNumber ?? 0) === 0 ? 'Steel your nerves. The first night is coming.' : 'Discuss what happened last night and share suspicions.' : effectiveDisplayPhase === 'vote' ? 'Cast your vote for the player you believe is a werewolf.' : effectiveDisplayPhase === 'eliminationResults' ? 'Review the outcome and prepare for the coming night.' : effectiveDisplayPhase === 'night' ? nightInstruction : null;
    const instructionNode = (()=>{
        if (!phaseSubInstruction) return null;
        // For roles that have limited resources (ex: Hunter shots, Trapper alerts, Doctor self-protect),
        // highlight the resource portion of the instruction text to match the info popover color.
        if (effectiveDisplayPhase !== 'night') {
            return phaseSubInstruction;
        }
        if (typeof phaseSubInstruction !== 'string') return phaseSubInstruction;
        const highlightFromMarkerToEnd = (marker)=>{
            const idx = phaseSubInstruction.indexOf(marker);
            if (idx === -1) return null;
            const before = phaseSubInstruction.slice(0, idx).trimEnd();
            const after = phaseSubInstruction.slice(idx);
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            before,
                            " "
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                        lineNumber: 252,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sky-300 font-semibold",
                        children: after
                    }, void 0, false, {
                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                        lineNumber: 253,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true);
        };
        const highlightExactSentence = (sentence)=>{
            const idx = phaseSubInstruction.indexOf(sentence);
            if (idx === -1) return null;
            const before = phaseSubInstruction.slice(0, idx).trimEnd();
            const after = phaseSubInstruction.slice(idx + sentence.length).trimStart();
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    before ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            before,
                            " "
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                        lineNumber: 265,
                        columnNumber: 21
                    }, this) : null,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sky-300 font-semibold",
                        children: sentence
                    }, void 0, false, {
                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                        lineNumber: 266,
                        columnNumber: 11
                    }, this),
                    after ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            " ",
                            after
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                        lineNumber: 267,
                        columnNumber: 20
                    }, this) : null
                ]
            }, void 0, true);
        };
        if (roleName === 'Hunter') {
            return highlightFromMarkerToEnd('Shots remaining:') ?? phaseSubInstruction;
        }
        if (roleName === 'Trapper') {
            return highlightFromMarkerToEnd('Alerts remaining:') ?? phaseSubInstruction;
        }
        if (roleName === 'Doctor') {
            return highlightExactSentence('You may protect yourself once per game.') ?? phaseSubInstruction;
        }
        return phaseSubInstruction;
    })();
    const eliminationResultsKey = eliminationResult?.noElimination === true ? `elim-result-none-${currentDayNumber ?? 0}` : eliminationResult && 'userId' in eliminationResult ? `elim-result-${eliminationResult.userId}` : `elim-result-waiting-${currentDayNumber ?? 0}`;
    const isHost = !!session?.user?.id && !!hostUserId && session.user.id === hostUserId;
    /* -----------------------------------------------------------------------
     Chat Refresh Key

     Forces `GameChat` to refresh when phase/role/alive status changes (which
     changes the user's chat audience/permissions).
  ----------------------------------------------------------------------- */ const chatRefreshKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$selectors$2f$gameUiSelectors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildChatRefreshKey"])({
        currentPhase,
        roleName,
        selfAlive,
        started
    });
    const roleToneClass = roleInfo?.faction === 'Enemy' ? 'reveal-role-werewolf' : roleName === 'Jester' ? 'reveal-role-jester' : roleName === 'Executioner' ? 'reveal-role-executioner' : roleName === 'Villager' ? 'reveal-role-villager' : 'reveal-role-special';
    const endGameButton = isHost ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        className: "game-button-secondary max-w-xs mx-auto",
        onClick: ()=>{
            if (!lobbyNameKey) return;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["endGame"])(lobbyNameKey, (err, res)=>{
                if (err || !res?.ok) {
                    console.error(res?.error ?? 'Failed to end game');
                }
            });
        },
        children: "End Game (Temporary)"
    }, void 0, false, {
        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
        lineNumber: 325,
        columnNumber: 5
    }, this) : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            currentPhase === 'lobby' && lobbyInfo?.startingAt ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameStartingScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                startingRemainingSeconds: startingRemainingSeconds
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 344,
                columnNumber: 9
            }, this) : currentPhase === 'roleReveal' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$RoleRevealScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                phaseEndsAt: currentPhaseEndsAt,
                revealState: revealState,
                roleName: roleName,
                roleToneClass: roleToneClass,
                endGameButton: endGameButton
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 346,
                columnNumber: 9
            }, this) : currentPhase === 'nightResults' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$NightResultsScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                revealState: nightResultRevealState,
                revealDeath: revealDeath,
                endGameButton: endGameButton
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 354,
                columnNumber: 9
            }, this) : currentPhase === 'endGame' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$EndGameScene$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                didWin: didWin,
                winningFaction: winningFaction,
                endGameButton: endGameButton
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 360,
                columnNumber: 9
            }, this) : currentPhase === 'gameResults' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "game-cinematic-scene min-h-[100svh]"
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 366,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: [
                    'min-h-[100svh] px-4 sm:px-6 py-6 sm:py-12 pb-80',
                    isNightCyclePhase ? 'game-cinematic-scene' : ''
                ].join(' '),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "mx-auto w-full max-w-3xl mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-left",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "game-tight-label",
                                        children: "Lobby"
                                    }, void 0, false, {
                                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                        lineNumber: 376,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "game-title text-left leading-tight",
                                        children: lobbyNameKey ?? '...'
                                    }, void 0, false, {
                                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                        lineNumber: 377,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                lineNumber: 375,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$PlayerRoleCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                roleName: roleName,
                                roleDisplayName: roleDisplayName,
                                roleInfo: roleInfo,
                                hunterShotsRemaining: hunterShotsRemaining,
                                trapperAlertsRemaining: trapperAlertsRemaining,
                                executionerTargetName: executionerTargetName,
                                executionerTargetUserId: executionerTargetUserId
                            }, void 0, false, {
                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                lineNumber: 381,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                        lineNumber: 374,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto w-full max-w-3xl text-center space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                className: "game-title",
                                                children: isDayCyclePhase ? `Day ${currentDayNumber ?? 0}` : isNightCyclePhase ? `Night ${currentNightNumber ?? 1}` : 'Game'
                                            }, void 0, false, {
                                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                lineNumber: 395,
                                                columnNumber: 17
                                            }, this),
                                            phaseSubLabel ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-slate-300/90 text-xs uppercase tracking-[0.2em]",
                                                children: phaseSubLabel
                                            }, void 0, false, {
                                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                lineNumber: 403,
                                                columnNumber: 19
                                            }, this) : null,
                                            phaseSubInstruction ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-slate-300 text-sm",
                                                children: instructionNode
                                            }, void 0, false, {
                                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                lineNumber: 408,
                                                columnNumber: 19
                                            }, this) : null
                                        ]
                                    }, void 0, true),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col items-center gap-3",
                                        children: [
                                            currentPhase !== 'nightActionResults' && currentPhase !== 'eliminationResults' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$PhaseTimer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                phaseEndsAt: currentPhaseEndsAt,
                                                phaseDurationMs: phaseDurationMs
                                            }, void 0, false, {
                                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                lineNumber: 414,
                                                columnNumber: 19
                                            }, this) : null,
                                            effectiveDisplayPhase === 'night' && roleName === 'Trapper' && selfAlive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: [
                                                    'game-button-secondary max-w-xs mx-auto',
                                                    trapperAlertActive ? 'game-button-alert-active' : trapperAlertsRemaining > 0 ? 'game-button-alert-ready' : '',
                                                    'disabled:cursor-not-allowed disabled:opacity-100'
                                                ].join(' '),
                                                disabled: currentPhase !== 'night' || !trapperAlertActive && trapperAlertsRemaining <= 0,
                                                onClick: ()=>{
                                                    if (!lobbyNameKey || currentPhase !== 'night') return;
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toggleTrapperAlert"])(lobbyNameKey);
                                                },
                                                children: trapperAlertActive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "flex flex-col items-center justify-center leading-tight",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "inline-flex items-center justify-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "relative flex h-2.5 w-2.5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-white/70 opacity-75"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                                            lineNumber: 446,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "relative inline-flex h-2.5 w-2.5 rounded-full bg-white"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                                            lineNumber: 447,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                                    lineNumber: 445,
                                                                    columnNumber: 27
                                                                }, this),
                                                                "Alert Active"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                            lineNumber: 444,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "mt-1 text-[11px] font-semibold text-emerald-100/90",
                                                            children: "Click to deactivate"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                            lineNumber: 451,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                    lineNumber: 443,
                                                    columnNumber: 23
                                                }, this) : trapperAlertsRemaining <= 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "flex flex-col items-center justify-center leading-tight",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "No Alerts Remaining"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                        lineNumber: 457,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                    lineNumber: 456,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "flex flex-col items-center justify-center leading-tight",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Activate Alert"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                        lineNumber: 461,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                    lineNumber: 460,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                                lineNumber: 422,
                                                columnNumber: 19
                                            }, this) : null
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                        lineNumber: 411,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                lineNumber: 393,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$PlayerList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                members: sortedMembers,
                                renderMemberRow: (member)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$MemberActionRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        lobbyName: lobbyNameKey,
                                        member: member,
                                        currentPhase: currentPhase,
                                        effectiveDisplayPhase: effectiveDisplayPhase,
                                        roleName: roleName,
                                        selfAlive: selfAlive,
                                        currentUserId: session?.user?.id,
                                        werewolfUserIds: werewolfUserIds,
                                        hunterShotsRemaining: hunterShotsRemaining,
                                        doctorSelfProtectUsed: doctorSelfProtectUsed,
                                        executionerTargetUserId: executionerTargetUserId,
                                        selectedNightActionTargetId: selectedNightActionTargetId,
                                        setSelectedNightActionTargetId: setSelectedNightActionTargetId,
                                        selectedVoteTargetId: selectedVoteTargetId,
                                        setSelectedVoteTargetId: setSelectedVoteTargetId,
                                        setViewingNotebook: setViewingNotebook
                                    }, member.userId, false, {
                                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                        lineNumber: 472,
                                        columnNumber: 17
                                    }, void 0)
                            }, void 0, false, {
                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                lineNumber: 469,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$EliminationResultsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                currentPhase: currentPhase,
                                eliminationResultsKey: eliminationResultsKey,
                                eliminationResult: eliminationResult
                            }, void 0, false, {
                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                lineNumber: 493,
                                columnNumber: 13
                            }, this),
                            endGameButton ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pt-4",
                                children: endGameButton
                            }, void 0, false, {
                                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                                lineNumber: 498,
                                columnNumber: 30
                            }, this) : null
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                        lineNumber: 392,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 368,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameFloatingPanels$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                currentPhase: currentPhase,
                lobbyName: lobbyNameKey,
                currentUserId: session?.user?.id,
                chatRefreshKey: chatRefreshKey,
                canWriteNotebook: canWriteNotebook,
                onNotesChange: (notes)=>{
                    if (!lobbyNameKey) return;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$actions$2f$gameSocketActions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateNotebook"])(lobbyNameKey, notes);
                },
                viewingNotebook: viewingNotebook,
                onCloseNotebook: ()=>setViewingNotebook(null)
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 502,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$game$2f$GameOverlays$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                phaseOverlayState: phaseOverlayState,
                showResultsFadeOut: currentPhase === 'gameResults'
            }, void 0, false, {
                fileName: "[project]/app/lobby/[lobbyName]/game/page.tsx",
                lineNumber: 515,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(LobbyGamePage, "q9sxFBxPE5tyQtLEuWwnw9q6rDA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSession"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyRealtime$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLobbyRealtime"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$usePresenceView$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePresenceView"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useLobbyGameState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLobbyGameState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$hooks$2f$useGamePhaseAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGamePhaseAnimation"]
    ];
});
_c = LobbyGamePage;
var _c;
__turbopack_context__.k.register(_c, "LobbyGamePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_c9283175._.js.map