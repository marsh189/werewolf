(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_lobby_[lobbyName]_game_layout_tsx_4c9e30f8._.js"
],
    source: "dynamic"
});
