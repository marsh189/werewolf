(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ea14dbb9._.js",
  "static/chunks/_3a0d70d1._.js"
],
    source: "dynamic"
});
